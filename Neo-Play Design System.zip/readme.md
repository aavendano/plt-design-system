# Neo-Play Design System

> **Editorial commerce for modern brands** — A neo-brutalista UI kit combining bold editorial aesthetics with polished e-commerce patterns.

## Overview

Neo-Play is an editorial commerce platform built for modern direct-to-consumer brands. The UI blends editorial publishing conventions (full-bleed hero, promo strips, magazine-style type) with e-commerce essentials (product grid, cart drawer, variant selection). The visual aesthetic is **neo-brutalist-soft**: high contrast, visible structure, hard offset shadows — clean and premium, not raw.

## Sources

- **`uploads/global.css`** — Primary CSS source. Contains the full daisyUI 5 theme definition (`@plugin "daisyui/theme"`), all custom utilities (`@utility theme-elevated`, `theme-bordered`, etc.), and cart drawer animation CSS.
- **`daisyui/`** — Mounted local daisyUI 5 documentation (SKILL.md, component API references, color guide).
- No Figma file or GitHub repo was provided for this session.

## Markets

US (en/es) and CA (en/fr) — UI copy defaults to neutral English.

---

## Content Fundamentals

### Voice & Tone
- **Direct and confident.** No hedging, no corporate softness.
- **Playful but edited.** Wit is welcome; fluff is not.
- **Benefit-first.** Lead with what the customer gains.
- **No exclamation drama** — genuine excitement earns a `!`, filler doesn't.

### Casing
- **ALL-CAPS** for button labels, badges, navbar links (Space Grotesk Bold)
- **Title case or uppercase** for short display headlines (Fjalla One)
- **Sentence case** for body copy and editorial prose

### Copy Patterns
| Context | Example |
|---|---|
| Primary CTA | "Shop Now", "Add to Cart", "View Collection" |
| Secondary CTA | "Learn More", "See All", "View Details" |
| Badges | "NEW", "SALE", "SOLD OUT", "–20%" |
| Navigation | "Collections", "New Arrivals", "Brand", "Blog", "Locations" |
| Newsletter | "Stay in the loop", "No spam. Just good stuff." |
| Promo strip | "Free shipping on orders over $75 — Shop Now" |

No emoji in UI chrome. Emoji may appear in editorial/blog content where the brand voice allows.

---

## Visual Foundations

### Colors

| Token | Hex / OKLCH | Name | Role |
|---|---|---|---|
| `--color-primary` | `#533278` | Deep Royal Purple | CTAs, brand accents, product card image borders |
| `--color-secondary` | `#F4436C` | Vibrant Rose Pink | Promo buttons, badges, footer underlines |
| `--color-accent` | `#0C7489` | Deep Teal | Links, info states |
| `--color-base-100` | `oklch(98% 0.002 247.839)` | Cool Off-White | Page and card backgrounds |
| `--color-base-200` | `oklch(98% 0 0)` | Near White | Navbar background |
| `--color-base-300` | `oklch(95% 0 0)` | Soft Gray | Footer, placeholder fills |
| `--color-base-content` | `oklch(37% 0.044 257.287)` | Slate Blue-Gray | Text, borders, shadows |
| `--color-warning` | `oklch(96% 0.059 95.617)` | Warm Promo Yellow | Hero bands, newsletter backgrounds |
| `--color-neutral` | `oklch(14% 0.005 285.823)` | Near Black | Strong accent elements |

### Typography

| Role | Font | Usage |
|---|---|---|
| **Display** | Fjalla One | Headlines, section titles, product names — uppercase, tight tracking |
| **Body** | Atkinson Hyperlegible | Paragraphs, descriptions, editorial prose |
| **Labels** | Space Grotesk 700 | Button labels, badges, navbar links, prices — bold uppercase |

⚠️ **Font substitution note:** All three typefaces are loaded from Google Fonts CDN via `@import` in `tokens/typography.css`. Replace with `@font-face` rules pointing to local binaries if you have licensed files.

### Backgrounds
- Primarily `base-100` (near-white) — clean, editorial
- Hero: `warning` (warm pale yellow) + `3px base-content` bottom border
- Promo strip: `primary` (purple) + `primary-content` text
- Footer: `base-300` (soft gray canvas)
- **No gradients. No glassmorphism. No dark mode.**

### Animation & Motion
- **Hover lift:** `translateY(-2px)` + hard shadow appears — `150ms ease`
- **Active press:** `translateY(2px)` + shadow disappears
- **Card hover:** `translateY(-4px)`, shadow offset grows from `2px → 5px`
- **Cart drawer slide-in:** `translateX(100% → 0)`, `250ms cubic-bezier(0.22, 1, 0.36, 1)`
- No bounces on UI elements. No infinite decorative loops.

### Borders
- **Standard:** `1.5px solid var(--color-base-content)` — default for inputs, cards, components
- **Heavy:** `3px solid var(--color-base-content)` — section dividers, hero bottom, navbar bottom, cart drawer left
- **Color accent:** Product card bottom border uses `--color-primary`
- Zero blur radius. Hard edges only.

### Shadows — Hard Offset (Neo-Brutalista)
All shadows use `X Y 0 0 color` — no blur, no spread except for sidebar.

| Token | Value | Use |
|---|---|---|
| `--shadow-sm` | `2px 2px 0 0` | Default elevated cards |
| `--shadow-md` | `4px 4px 0 0` | Hover state |
| `--shadow-lg` | `6px 6px 0 0` | Featured/emphasized cards |
| `--shadow-xl` | `10px 10px 0 0` | Hero cards |
| `--shadow-sidebar` | `5px 0 0 0` | Cart drawer, sidebars |

Shadow color is always `var(--color-base-content)` (slate blue-gray).

### Corners
- Global radius: `0.25rem` (4px) — subtly rounded, never pill-shaped
- Selectors, fields, boxes: all `0.25rem`

### Cards
- `base-100` background
- `1.5px solid base-content` all-round border
- `2px 2px 0 0 base-content` default shadow
- **Hover:** `translateY(-4px)`, shadow grows to `5px 5px`
- Product cards: additional `3px solid primary` bottom border

### Imagery
- **Product photos:** square aspect ratio (1:1)
- **Hero:** full-bleed, edge-to-edge
- **Palette:** clean, cool-to-neutral — consistent with purple/teal accent system
- No grain, no hand-drawn illustrations
- Placeholder images: `picsum.photos/{w}/{h}`

---

## Iconography

**Icon system: Material Symbols Outlined** (Google Fonts CDN)

Loaded via `tokens/typography.css` — any consumer that links `styles.css` gets the font automatically.

Usage pattern:
```html
<span style="font-family: 'Material Symbols Outlined'; font-size: 22px;">shopping_bag</span>
```

Common icons in this system:
`shopping_bag` · `person` · `search` · `close` · `arrow_forward` · `menu` · `check_circle` · `local_shipping` · `star` · `expand_more` · `info` · `warning` · `error` · `check`

No custom SVG icon set. No emoji as icons.

---

## File Index

```
styles.css                       ← global CSS entry point (imports only)
tokens/
  colors.css                     ← brand + base + semantic color tokens
  typography.css                 ← font families, scale, Google Fonts @import
  spacing.css                    ← spacing scale + layout constants
  effects.css                    ← shadow, border, radius, transition tokens
components/
  actions/                       ← Button
  data-display/                  ← Badge, ProductCard
  navigation/                    ← Navbar
  forms/                         ← Input, Select, Checkbox
  commerce/                      ← PromoStrip, Newsletter, CartDrawer
  feedback/                      ← Toast, Alert
guidelines/                      ← Foundation specimen cards (DS tab)
ui_kits/
  ecommerce/                     ← E-commerce site: Home, PLP, PDP
  blog/                          ← Editorial blog: Article list + detail
assets/                          ← (add logos, illustrations here)
readme.md                        ← this file
SKILL.md                         ← Agent skill definition
```

### Components

| Component | Directory | Starting Point |
|---|---|---|
| `Button` | `components/actions/` | ✓ Actions |
| `Badge` | `components/data-display/` | — |
| `ProductCard` | `components/data-display/` | ✓ Commerce |
| `Navbar` | `components/navigation/` | — |
| `Input` | `components/forms/` | — |
| `Select` | `components/forms/` | — |
| `Checkbox` | `components/forms/` | — |
| `PromoStrip` | `components/commerce/` | ✓ Commerce |
| `Newsletter` | `components/commerce/` | ✓ Commerce |
| `CartDrawer` | `components/commerce/` | — |
| `Toast` | `components/feedback/` | — |
| `Alert` | `components/feedback/` | — |

---

## Caveats

⚠️ **Fonts from CDN:** Fjalla One, Atkinson Hyperlegible, Space Grotesk, and Material Symbols Outlined are all loaded from Google Fonts CDN. Replace the `@import url()` in `tokens/typography.css` with `@font-face` rules if you have local font binaries.

⚠️ **No Figma provided:** All visual foundations are derived directly from `uploads/global.css` and the daisyUI documentation. If a Figma file becomes available, cross-reference it for pixel-level spec differences.

⚠️ **daisyUI runtime not bundled:** The `uploads/global.css` references Tailwind 4 plugins (`@plugin "daisyui"`). This design system mirrors those token values as raw CSS custom properties. Consuming Tailwind 4 projects should use `uploads/global.css` as their production stylesheet; this DS's `styles.css` provides the token foundation for design-system tooling.
