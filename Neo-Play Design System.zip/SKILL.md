---
name: neo-play-design
description: Use this skill to generate well-branded interfaces and assets for Neo-Play, an editorial commerce platform for modern DTC brands. Contains essential design guidelines, colors, typography, fonts, assets, and reusable UI components for prototyping or production.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

---

## Quick Reference

### Brand
- **Name:** Neo-Play
- **Tagline:** Editorial commerce for modern brands
- **Aesthetic:** Neo-brutalist-soft — high contrast, visible borders, hard offset shadows, premium but playful

### Colors
| Role | Value | Name |
|---|---|---|
| Primary | `#533278` | Deep Royal Purple |
| Secondary | `#F4436C` | Vibrant Rose Pink |
| Accent | `#0C7489` | Deep Teal |
| Background | `oklch(98% 0.002 247.839)` | Cool Off-White |
| Text/borders | `oklch(37% 0.044 257.287)` | Slate Blue-Gray |
| Hero band | `oklch(96% 0.059 95.617)` | Warm Promo Yellow |

### Typography
| Role | Font | Rendering |
|---|---|---|
| Display | Fjalla One | Bold, UPPERCASE, tight tracking (-0.02em) |
| Body | Atkinson Hyperlegible | Regular/Bold, sentence case, 1.6 line-height |
| Labels | Space Grotesk 700 | UPPERCASE, 0.06em tracking |

Load from Google Fonts:
```html
<link href="https://fonts.googleapis.com/css2?family=Fjalla+One&family=Atkinson+Hyperlegible:wght@400;700&family=Space+Grotesk:wght@400;700&family=Material+Symbols+Outlined&display=swap" rel="stylesheet">
```

### Visual rules (memorize these)
- **Shadows:** hard offset ONLY — `2px 2px 0 0 var(--color-base-content)` (no blur, no softness)
- **Borders:** 1.5px standard, 3px heavy (section dividers, navbar bottom, hero bottom)
- **Radius:** 0.25rem (4px) — never pill-shaped
- **Hover:** `translateY(-2px)` + shadow appears (150ms ease)
- **Active:** `translateY(2px)` + shadow gone
- **No gradients, no glassmorphism, no dark mode, no emoji in UI chrome**

### Icons
Material Symbols Outlined — load from Google Fonts CDN.
Usage: `<span style="font-family: 'Material Symbols Outlined'">shopping_bag</span>`

### Components (available in `_ds_bundle.js`)
- `Button` — primary, secondary, accent, neutral, warning, outline, ghost variants
- `Badge` — all semantic variants + outline style
- `ProductCard` — square image, title, price, badge, hover animation
- `Navbar` — sticky, thick bottom border, logo + nav + cart badge
- `Input`, `Select`, `Checkbox` — forms with uppercase labels
- `PromoStrip` — full-width announcement banner
- `Newsletter` — email signup, warning yellow background
- `CartDrawer` — slide-in panel with item list + subtotal
- `Toast`, `Alert` — semantic feedback

### Loading the design system in HTML
```html
<link rel="stylesheet" href="./_ds/[folder]/styles.css">
<script src="./_ds/[folder]/_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, ProductCard } = window.NeoPlayDesignSystem_3742b6;
  // mount with ReactDOM.createRoot(...)
</script>
```

### Key layout patterns
- Max-width container: `max-width: 1280px; margin: 0 auto; padding: 0 clamp(1.5rem, 4vw, 3rem)`
- Section vertical padding: `clamp(3rem, 6vw, 5rem)`
- Product grid: `display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.25rem`
- Hero: warning yellow bg + `border-bottom: 3px solid base-content`
- Promo strip: primary bg + primary-content text (place above Navbar)
- Newsletter: warning yellow bg + heavy borders
- Footer: base-300 bg + heavy top border

### Page structure template
```
[PromoStrip]         ← above navbar
[Navbar sticky]
[Page content]
[Newsletter]
[Footer]
```
