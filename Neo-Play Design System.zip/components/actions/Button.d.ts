/**
 * Neo-Play primary action button.
 * Neo-brutalista style: bold uppercase labels, hard offset shadow on hover.
 */
export interface ButtonProps {
  /** Visual style variant */
  variant?: 'primary' | 'secondary' | 'accent' | 'neutral' | 'warning' | 'outline' | 'ghost';
  /** Button size */
  size?: 'sm' | 'md' | 'lg' | 'xl';
  /** Button content */
  children?: React.ReactNode;
  /** Disable interaction */
  disabled?: boolean;
  /** Click handler */
  onClick?: () => void;
  /** Fill parent width */
  fullWidth?: boolean;
  /** Material Symbol icon name (e.g. "shopping_bag") */
  icon?: string;
  /** Icon placement relative to label */
  iconPosition?: 'left' | 'right';
  /** Show persistent elevated shadow (base state) */
  elevated?: boolean;
  /** HTML button type */
  type?: 'button' | 'submit' | 'reset';
}

export declare function Button(props: ButtonProps): JSX.Element;
