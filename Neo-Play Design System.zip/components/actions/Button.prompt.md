Use `Button` for any interactive action. Prefer `variant="primary"` for the single most-important CTA on a view; use `outline` for secondary actions; `ghost` for low-emphasis dismissals.

```jsx
// Primary hero CTA
<Button variant="primary" size="xl" icon="shopping_bag" iconPosition="right">
  Shop Now
</Button>

// Secondary action
<Button variant="outline" size="md">View Collection</Button>

// With persistent shadow
<Button variant="primary" elevated>Add to Cart</Button>

// Full-width form submit
<Button variant="primary" fullWidth type="submit">Subscribe</Button>

// Disabled
<Button variant="primary" disabled>Sold Out</Button>
```

**Variants:** `primary` (purple) · `secondary` (rose pink) · `accent` (teal) · `neutral` (near-black) · `warning` (promo yellow) · `outline` (transparent + border) · `ghost` (text only)

**Sizes:** `sm` · `md` · `lg` · `xl`

Labels are always uppercase via the component's built-in style — do not add `text-transform: uppercase` in the consumer.
