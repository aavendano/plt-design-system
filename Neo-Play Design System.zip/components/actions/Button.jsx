import React from 'react';

/**
 * Neo-Play primary action button. Neo-brutalista style: bold uppercase labels,
 * hard offset shadow on hover, subtle press animation.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  children,
  disabled = false,
  onClick,
  fullWidth = false,
  icon,
  iconPosition = 'left',
  elevated = false,
  type = 'button',
}) {
  const [hovered, setHovered] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);

  const variantStyles = {
    primary:   { background: 'var(--color-primary)',   color: 'var(--color-primary-content)',  border: '3px solid var(--color-primary)' },
    secondary: { background: 'var(--color-secondary)', color: '#ffffff',                        border: '3px solid var(--color-secondary)' },
    accent:    { background: 'var(--color-accent)',    color: 'var(--color-accent-content)',   border: '3px solid var(--color-accent)' },
    neutral:   { background: 'var(--color-neutral)',   color: 'var(--color-neutral-content)',  border: '3px solid var(--color-neutral)' },
    warning:   { background: 'var(--color-warning)',   color: 'var(--color-warning-content)',  border: '3px solid var(--color-base-content)' },
    outline:   { background: 'transparent',            color: 'var(--color-base-content)',     border: '3px solid var(--color-base-content)' },
    ghost:     { background: 'transparent',            color: 'var(--color-base-content)',     border: '3px solid transparent' },
  };

  const sizeStyles = {
    sm: { padding: '0.375rem 0.875rem', fontSize: '0.75rem',  iconSize: '16px', gap: '0.375rem' },
    md: { padding: '0.625rem 1.25rem',  fontSize: '0.8125rem', iconSize: '18px', gap: '0.5rem' },
    lg: { padding: '0.875rem 1.75rem',  fontSize: '0.9375rem', iconSize: '20px', gap: '0.5rem' },
    xl: { padding: '1.125rem 2.25rem',  fontSize: '1.0625rem', iconSize: '22px', gap: '0.625rem' },
  };

  const v = variantStyles[variant] || variantStyles.primary;
  const s = sizeStyles[size] || sizeStyles.md;

  const isActive = !disabled;
  const transform = !isActive ? 'none' : pressed ? 'translateY(2px)' : hovered ? 'translateY(-2px)' : 'none';
  const boxShadow = !isActive || pressed ? 'none'
    : hovered ? '3px 3px 0 0 var(--color-base-content)'
    : elevated ? '2px 2px 0 0 var(--color-base-content)'
    : 'none';

  const style = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    borderRadius: 'var(--radius-field, 0.25rem)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    width: fullWidth ? '100%' : 'auto',
    transition: 'transform 150ms ease, box-shadow 150ms ease',
    transform,
    boxShadow,
    whiteSpace: 'nowrap',
    userSelect: 'none',
    textDecoration: 'none',
    lineHeight: 1.2,
    ...v,
  };

  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontWeight: 'normal',
    fontStyle: 'normal',
    fontSize: s.iconSize,
    lineHeight: 1,
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
    flexShrink: 0,
  };

  return (
    <button
      type={type}
      style={style}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
    >
      {icon && iconPosition === 'left' && <span style={iconStyle}>{icon}</span>}
      {children}
      {icon && iconPosition === 'right' && <span style={iconStyle}>{icon}</span>}
    </button>
  );
}
