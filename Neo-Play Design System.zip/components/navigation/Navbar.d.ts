/**
 * Site navigation bar. Sticky top with logo, horizontal nav links, and action icons.
 * Thick bottom border (3px base-content). Height: 64px.
 */
export interface NavbarProps {
  /** Brand name or logomark text */
  logo?: string;
  /** Navigation link items */
  navItems?: Array<{ label: string; href: string }>;
  /** Cart icon click handler */
  onCartClick?: () => void;
  /** Number shown on cart badge (hidden when 0) */
  cartCount?: number;
  /** Search icon click handler (icon hidden if omitted) */
  onSearchClick?: () => void;
  /** Account icon click handler */
  onAccountClick?: () => void;
}

export declare function Navbar(props: NavbarProps): JSX.Element;
