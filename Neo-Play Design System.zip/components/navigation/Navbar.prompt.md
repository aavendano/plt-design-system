Place `Navbar` at the top of every page. It's sticky and uses `position: sticky; top: 0`. Wrap in a `CartDrawer` for the full cart interaction.

```jsx
// Basic navbar
<Navbar
  logo="NEO-PLAY"
  navItems={[
    { label: 'Collections', href: '/collections' },
    { label: 'New Arrivals', href: '/new' },
    { label: 'Brand',       href: '/brand' },
    { label: 'Blog',        href: '/blog' },
  ]}
  cartCount={2}
  onCartClick={() => setCartOpen(true)}
  onSearchClick={() => setSearchOpen(true)}
/>
```

**Notes:**
- Logo renders in Fjalla One, primary color (#533278)
- Nav links render in Space Grotesk 700 uppercase
- Cart badge: rose pink pill with item count (hidden at 0)
- Search icon only renders if `onSearchClick` is provided
