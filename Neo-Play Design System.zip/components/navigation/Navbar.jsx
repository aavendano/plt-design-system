import React from 'react';

/**
 * Site navigation bar. Sticky top, thick bottom border, logo + nav links + action icons.
 */
export function Navbar({
  logo = 'NEO-PLAY',
  navItems = [
    { label: 'Collections', href: '#' },
    { label: 'New Arrivals', href: '#' },
    { label: 'Brand',       href: '#' },
    { label: 'Blog',        href: '#' },
  ],
  onCartClick,
  cartCount = 0,
  onSearchClick,
  onAccountClick,
}) {
  const navStyle = {
    position: 'sticky',
    top: 0,
    zIndex: 50,
    background: 'var(--color-base-200)',
    borderBottom: '3px solid var(--color-base-content)',
    display: 'flex',
    alignItems: 'center',
    padding: '0 1.5rem',
    height: 'var(--navbar-height, 64px)',
    gap: '2rem',
    boxSizing: 'border-box',
  };

  const logoStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '1.375rem',
    fontWeight: 700,
    color: 'var(--color-primary)',
    textDecoration: 'none',
    letterSpacing: '-0.02em',
    whiteSpace: 'nowrap',
    flexShrink: 0,
  };

  const navListStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '1.75rem',
    flex: 1,
    listStyle: 'none',
    margin: 0,
    padding: 0,
  };

  const navLinkStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)',
    textDecoration: 'none',
    whiteSpace: 'nowrap',
  };

  const actionsStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.25rem',
    flexShrink: 0,
  };

  const iconBtnBase = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '40px',
    height: '40px',
    background: 'transparent',
    border: 'none',
    borderRadius: '0.25rem',
    cursor: 'pointer',
    color: 'var(--color-base-content)',
    padding: 0,
  };

  const iconSpanStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: '22px',
    lineHeight: 1,
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
  };

  const cartBadgeStyle = {
    position: 'absolute',
    top: '7px',
    right: '7px',
    background: 'var(--color-secondary)',
    color: '#fff',
    fontSize: '0.5rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    borderRadius: '100px',
    minWidth: '15px',
    height: '15px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    lineHeight: 1,
    padding: '0 2px',
  };

  return (
    <nav style={navStyle} aria-label="Main navigation">
      <a href="/" style={logoStyle}>{logo}</a>
      <ul style={navListStyle}>
        {navItems.map((item, i) => (
          <li key={i}>
            <a
              href={item.href}
              style={navLinkStyle}
              onClick={item.onClick ? (e) => { e.preventDefault(); item.onClick(); } : undefined}
            >
              {item.label}
            </a>
          </li>
        ))}
      </ul>
      <div style={actionsStyle}>
        {onSearchClick && (
          <button style={iconBtnBase} onClick={onSearchClick} aria-label="Search">
            <span style={iconSpanStyle}>search</span>
          </button>
        )}
        <button
          style={{ ...iconBtnBase, position: 'relative' }}
          onClick={onCartClick}
          aria-label={`Cart${cartCount > 0 ? `, ${cartCount} items` : ''}`}
        >
          <span style={iconSpanStyle}>shopping_bag</span>
          {cartCount > 0 && <span style={cartBadgeStyle}>{cartCount}</span>}
        </button>
        <button style={iconBtnBase} onClick={onAccountClick} aria-label="Account">
          <span style={iconSpanStyle}>person</span>
        </button>
      </div>
    </nav>
  );
}
