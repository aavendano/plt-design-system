import React from 'react';

/**
 * Dropdown select field with label and error state.
 * Custom expand_more icon replaces browser default chevron.
 */
export function Select({
  label,
  options = [],
  value,
  onChange,
  placeholder = 'Select an option',
  error,
  size = 'md',
  disabled = false,
  name,
  id,
  required = false,
}) {
  const [focused, setFocused] = React.useState(false);

  const sizes = {
    sm: { height: '36px', fontSize: '0.8125rem', padding: '0 2rem 0 0.75rem' },
    md: { height: '44px', fontSize: '0.9375rem', padding: '0 2rem 0 0.875rem' },
    lg: { height: '52px', fontSize: '1rem',      padding: '0 2rem 0 1rem' },
  };
  const s = sizes[size] || sizes.md;

  const borderColor = error ? 'var(--color-error-content)'
    : focused ? 'var(--color-primary)'
    : 'var(--color-base-content)';

  const wrapperStyle = { display: 'flex', flexDirection: 'column', gap: '0.375rem' };

  const labelStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)',
  };

  const selectStyle = {
    height: s.height,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    color: value ? 'var(--color-base-content)' : 'var(--color-base-content)',
    background: disabled ? 'var(--color-base-300)' : 'var(--color-base-100)',
    border: `1.5px solid ${borderColor}`,
    borderRadius: 'var(--radius-field, 0.25rem)',
    outline: 'none',
    width: '100%',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.6 : 1,
    appearance: 'none',
    WebkitAppearance: 'none',
    boxSizing: 'border-box',
    boxShadow: focused && !error ? '2px 2px 0 0 var(--color-primary)' : 'none',
    transition: 'border-color 150ms ease, box-shadow 150ms ease',
  };

  const iconStyle = {
    position: 'absolute',
    right: '0.625rem',
    top: '50%',
    transform: 'translateY(-50%)',
    pointerEvents: 'none',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '18px',
    color: 'var(--color-base-content)',
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal',
  };

  const messageStyle = {
    fontSize: '0.8125rem',
    color: 'var(--color-error-content)',
    margin: 0,
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
  };

  const fieldId = id || name;

  const normalizedOptions = options.map((opt) =>
    typeof opt === 'string' ? { value: opt, label: opt } : opt
  );

  return (
    <div style={wrapperStyle}>
      {label && (
        <label style={labelStyle} htmlFor={fieldId}>
          {label}
          {required && <span style={{ color: 'var(--color-secondary)', marginLeft: '3px' }}>*</span>}
        </label>
      )}
      <div style={{ position: 'relative' }}>
        <select
          id={fieldId}
          name={name}
          value={value}
          onChange={onChange}
          disabled={disabled}
          style={selectStyle}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        >
          {placeholder && <option value="" disabled>{placeholder}</option>}
          {normalizedOptions.map((opt, i) => (
            <option key={i} value={opt.value}>{opt.label}</option>
          ))}
        </select>
        <span style={iconStyle}>expand_more</span>
      </div>
      {error && <p style={messageStyle}>{error}</p>}
    </div>
  );
}
