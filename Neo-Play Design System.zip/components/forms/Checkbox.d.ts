/**
 * Custom checkbox with primary-color fill and Material Symbols checkmark icon.
 */
export interface CheckboxProps {
  /** Label text next to the checkbox */
  label?: string;
  /** Controlled checked state */
  checked?: boolean;
  /** Change handler */
  onChange?: (e: { target: { checked: boolean; name?: string } }) => void;
  /** Disable interaction */
  disabled?: boolean;
  /** Size variant */
  size?: 'sm' | 'md' | 'lg';
  /** HTML id attribute */
  id?: string;
  /** HTML name attribute */
  name?: string;
}

export declare function Checkbox(props: CheckboxProps): JSX.Element;
