import React from 'react';

/**
 * Text input field with label, hint, and error state.
 * Focus state shows primary-color border + hard shadow.
 */
export function Input({
  label,
  type = 'text',
  placeholder = '',
  value,
  onChange,
  error,
  hint,
  size = 'md',
  required = false,
  disabled = false,
  name,
  id,
  autoComplete,
}) {
  const [focused, setFocused] = React.useState(false);

  const sizes = {
    sm: { height: '36px', fontSize: '0.8125rem', padding: '0 0.75rem' },
    md: { height: '44px', fontSize: '0.9375rem', padding: '0 0.875rem' },
    lg: { height: '52px', fontSize: '1rem',      padding: '0 1rem' },
  };
  const s = sizes[size] || sizes.md;

  const borderColor = error ? 'var(--color-error-content)'
    : focused ? 'var(--color-primary)'
    : 'var(--color-base-content)';

  const wrapperStyle = { display: 'flex', flexDirection: 'column', gap: '0.375rem' };

  const labelStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)',
  };

  const inputStyle = {
    height: s.height,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    color: 'var(--color-base-content)',
    background: disabled ? 'var(--color-base-300)' : 'var(--color-base-100)',
    border: `1.5px solid ${borderColor}`,
    borderRadius: 'var(--radius-field, 0.25rem)',
    outline: 'none',
    width: '100%',
    transition: 'border-color 150ms ease, box-shadow 150ms ease',
    cursor: disabled ? 'not-allowed' : 'text',
    opacity: disabled ? 0.6 : 1,
    boxSizing: 'border-box',
    boxShadow: focused && !error ? '2px 2px 0 0 var(--color-primary)' : 'none',
  };

  const messageStyle = {
    fontSize: '0.8125rem',
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    color: error ? 'var(--color-error-content)' : 'var(--color-base-content)',
    opacity: error ? 1 : 0.6,
    margin: 0,
    lineHeight: 1.4,
  };

  const fieldId = id || name;

  return (
    <div style={wrapperStyle}>
      {label && (
        <label style={labelStyle} htmlFor={fieldId}>
          {label}
          {required && <span style={{ color: 'var(--color-secondary)', marginLeft: '3px' }}>*</span>}
        </label>
      )}
      <input
        id={fieldId}
        name={name}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        disabled={disabled}
        required={required}
        autoComplete={autoComplete}
        style={inputStyle}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
      />
      {(hint || error) && <p style={messageStyle}>{error || hint}</p>}
    </div>
  );
}
