/**
 * Text input field with uppercase label, focus highlight, and error/hint messaging.
 */
export interface InputProps {
  /** Field label (renders uppercase in Space Grotesk) */
  label?: string;
  /** HTML input type */
  type?: 'text' | 'email' | 'password' | 'number' | 'tel' | 'url' | 'search';
  /** Placeholder text */
  placeholder?: string;
  /** Controlled value */
  value?: string;
  /** Change handler */
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Error message (shows red border + message below) */
  error?: string;
  /** Helper text shown below input (overridden by error) */
  hint?: string;
  /** Input size */
  size?: 'sm' | 'md' | 'lg';
  /** Marks field as required (adds rose asterisk to label) */
  required?: boolean;
  /** Disable input */
  disabled?: boolean;
  /** Input name attribute */
  name?: string;
  /** Input id attribute (falls back to name) */
  id?: string;
  /** HTML autocomplete attribute */
  autoComplete?: string;
}

export declare function Input(props: InputProps): JSX.Element;
