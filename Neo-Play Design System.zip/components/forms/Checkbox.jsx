import React from 'react';

/**
 * Custom checkbox with primary-color fill and Material Symbols checkmark.
 */
export function Checkbox({
  label,
  checked = false,
  onChange,
  disabled = false,
  size = 'md',
  id,
  name,
}) {
  const sizeMap = { sm: 16, md: 20, lg: 24 };
  const sz = sizeMap[size] || 20;

  const handleClick = () => {
    if (!disabled && onChange) {
      onChange({ target: { checked: !checked, name } });
    }
  };

  const wrapperStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '0.625rem',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    userSelect: 'none',
  };

  const boxStyle = {
    width: `${sz}px`,
    height: `${sz}px`,
    border: `1.5px solid ${checked ? 'var(--color-primary)' : 'var(--color-base-content)'}`,
    borderRadius: 'var(--radius-selector, 0.25rem)',
    background: checked ? 'var(--color-primary)' : 'var(--color-base-100)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'background 150ms ease, border-color 150ms ease, box-shadow 150ms ease',
    flexShrink: 0,
    boxShadow: checked ? '2px 2px 0 0 var(--color-primary)' : 'none',
  };

  const checkStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: `${Math.round(sz * 0.72)}px`,
    color: 'var(--color-primary-content)',
    lineHeight: 1,
    fontWeight: 'normal',
    fontStyle: 'normal',
    opacity: checked ? 1 : 0,
    transition: 'opacity 100ms ease',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
  };

  const labelStyle = {
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    fontSize: '0.9375rem',
    color: 'var(--color-base-content)',
    lineHeight: 1.4,
  };

  return (
    <label style={wrapperStyle} onClick={handleClick}>
      <input
        type="checkbox"
        id={id}
        name={name}
        checked={checked}
        onChange={onChange}
        disabled={disabled}
        style={{ position: 'absolute', opacity: 0, width: 0, height: 0, pointerEvents: 'none' }}
        readOnly
      />
      <div style={boxStyle}>
        <span style={checkStyle}>check</span>
      </div>
      {label && <span style={labelStyle}>{label}</span>}
    </label>
  );
}
