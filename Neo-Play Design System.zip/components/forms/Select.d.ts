/**
 * Dropdown select with uppercase label and custom expand_more chevron.
 */
export interface SelectProps {
  /** Field label */
  label?: string;
  /** Options array — strings or { value, label } objects */
  options?: Array<string | { value: string; label: string }>;
  /** Controlled selected value */
  value?: string;
  /** Change handler */
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  /** Placeholder option (disabled, selected by default) */
  placeholder?: string;
  /** Error message */
  error?: string;
  /** Field size */
  size?: 'sm' | 'md' | 'lg';
  /** Disable field */
  disabled?: boolean;
  /** HTML name attribute */
  name?: string;
  /** HTML id (falls back to name) */
  id?: string;
  /** Show required asterisk */
  required?: boolean;
}

export declare function Select(props: SelectProps): JSX.Element;
