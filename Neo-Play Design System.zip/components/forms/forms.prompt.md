# Forms Components

Use `Input`, `Select`, and `Checkbox` to build product filter panels, checkout forms, newsletter signups, and account settings.

## Input

```jsx
<Input
  label="Email Address"
  type="email"
  placeholder="you@example.com"
  required
  hint="We'll never share your email."
/>

<Input label="Promo Code" error="Invalid code. Try again." />
```

## Select

```jsx
<Select
  label="Size"
  options={['XS', 'S', 'M', 'L', 'XL']}
  placeholder="Choose a size"
/>

<Select
  label="Sort by"
  options={[
    { value: 'newest', label: 'Newest First' },
    { value: 'price-asc', label: 'Price: Low to High' },
    { value: 'price-desc', label: 'Price: High to Low' },
  ]}
/>
```

## Checkbox

```jsx
<Checkbox label="Save payment info for next time" checked={saved} onChange={e => setSaved(e.target.checked)} />
<Checkbox label="Subscribe to newsletter" size="lg" />
```

## Form layout pattern

```jsx
<form style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', maxWidth: '28rem' }}>
  <Input label="First Name" name="first" required />
  <Input label="Email" type="email" name="email" required />
  <Select label="Country" options={['United States', 'Canada']} />
  <Checkbox label="I agree to the terms" />
  <Button variant="primary" fullWidth type="submit">Continue</Button>
</form>
```
