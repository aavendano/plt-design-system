Use `Badge` for compact status labels — product lifecycle ("NEW", "SALE"), inventory ("SOLD OUT"), categories, and semantic status indicators.

```jsx
// Product status (most common use)
<Badge variant="secondary">New</Badge>
<Badge variant="error">Sale</Badge>
<Badge variant="neutral">Sold Out</Badge>

// Outline style (on dark backgrounds)
<Badge variant="primary" outline>Limited Edition</Badge>

// Semantic feedback
<Badge variant="success">In Stock</Badge>
<Badge variant="warning">Low Stock</Badge>
```

**Variants:** `primary` (purple) · `secondary` (rose pink) · `accent` (teal) · `neutral` · `success` · `warning` · `error` · `info` · `ghost`

Text is always uppercase — don't add `text-transform` in the consumer.
