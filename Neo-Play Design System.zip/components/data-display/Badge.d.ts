/**
 * Status badge for product labels, category tags, and indicators.
 * Renders uppercase Space Grotesk text in a small colored chip.
 */
export interface BadgeProps {
  /** Color variant */
  variant?: 'primary' | 'secondary' | 'accent' | 'neutral' | 'success' | 'warning' | 'error' | 'info' | 'ghost';
  /** Badge size */
  size?: 'sm' | 'md' | 'lg';
  /** Render outline style (border only, no fill) */
  outline?: boolean;
  /** Label text */
  children?: React.ReactNode;
}

export declare function Badge(props: BadgeProps): JSX.Element;
