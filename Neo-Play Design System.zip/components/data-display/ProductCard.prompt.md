Use `ProductCard` in product grids (homepage, PLP). Renders square image with primary bottom border, Fjalla One title, price row, and optional add-to-cart button.

```jsx
// Default — links to PDP
<ProductCard
  title="Premium Hoodie"
  price="$89.00"
  image="https://picsum.photos/seed/hoodie/400/400"
  badge="New"
  href="/products/premium-hoodie"
/>

// Sale item
<ProductCard
  title="Graphic Tee"
  price="$35.00"
  originalPrice="$55.00"
  badge="Sale"
  href="/products/graphic-tee"
/>

// With add-to-cart CTA (for quick-add on PLP)
<ProductCard
  title="Canvas Cap"
  price="$42.00"
  onAddToCart={() => addToCart('cap')}
/>

// Product grid (3-up)
<div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.25rem' }}>
  <ProductCard title="Item A" price="$49.00" />
  <ProductCard title="Item B" price="$64.00" badge="New" />
  <ProductCard title="Item C" price="$29.00" originalPrice="$45.00" badge="Sale" />
</div>
```

Image always renders at 1:1 aspect ratio. Without `image`, uses a picsum placeholder seeded by `title`.
