import React from 'react';

/**
 * E-commerce product card with square image, title, price, optional badge and CTA.
 * Features neo-brutalista border + hard offset shadow with hover lift animation.
 */
export function ProductCard({
  title = 'Product Name',
  price = '$99.00',
  originalPrice,
  image,
  badge,
  href = '#',
  onAddToCart,
}) {
  const [hovered, setHovered] = React.useState(false);

  const cardStyle = {
    background: 'var(--color-base-100)',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: 'var(--radius-box, 0.25rem)',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    transition: 'transform 150ms ease, box-shadow 150ms ease',
    transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
    boxShadow: hovered ? '5px 5px 0 0 var(--color-base-content)' : '2px 2px 0 0 var(--color-base-content)',
    textDecoration: 'none',
    color: 'inherit',
    cursor: 'pointer',
  };

  const imageWrapStyle = {
    position: 'relative',
    width: '100%',
    paddingBottom: '100%',
    background: 'var(--color-base-300)',
    overflow: 'hidden',
    borderBottom: '3px solid var(--color-primary)',
    flexShrink: 0,
  };

  const imageStyle = {
    position: 'absolute',
    inset: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    display: 'block',
  };

  const badgeStyle = {
    position: 'absolute',
    top: '0.75rem',
    left: '0.75rem',
    zIndex: 1,
    background: 'var(--color-secondary)',
    color: '#fff',
    fontSize: '0.625rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    padding: '0.2rem 0.55rem',
    borderRadius: '0.25rem',
    lineHeight: 1,
    border: '1.5px solid transparent',
  };

  const bodyStyle = {
    padding: '1rem 1rem 1.25rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
    flex: 1,
  };

  const titleStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '1rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '-0.01em',
    color: 'var(--color-base-content)',
    lineHeight: 1.25,
    margin: 0,
  };

  const priceRowStyle = {
    display: 'flex',
    alignItems: 'baseline',
    gap: '0.5rem',
  };

  const priceStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '1rem',
    fontWeight: 700,
    color: 'var(--color-base-content)',
  };

  const originalPriceStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.875rem',
    color: 'var(--color-base-content)',
    opacity: 0.45,
    textDecoration: 'line-through',
  };

  const ctaBtnStyle = {
    marginTop: '0.625rem',
    padding: '0.5rem 1rem',
    background: 'transparent',
    color: 'var(--color-base-content)',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.75rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    cursor: 'pointer',
    width: '100%',
    lineHeight: 1,
  };

  const imgSrc = image || `https://picsum.photos/seed/${encodeURIComponent(title)}/400/400`;

  return (
    <a
      href={href}
      style={cardStyle}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div style={imageWrapStyle}>
        <img src={imgSrc} alt={title} style={imageStyle} />
        {badge && <span style={badgeStyle}>{badge}</span>}
      </div>
      <div style={bodyStyle}>
        <h3 style={titleStyle}>{title}</h3>
        <div style={priceRowStyle}>
          <span style={priceStyle}>{price}</span>
          {originalPrice && <span style={originalPriceStyle}>{originalPrice}</span>}
        </div>
        {onAddToCart && (
          <button
            style={ctaBtnStyle}
            onClick={(e) => { e.preventDefault(); onAddToCart(); }}
          >
            Add to Cart
          </button>
        )}
      </div>
    </a>
  );
}
