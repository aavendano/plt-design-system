import React from 'react';

/**
 * Status badge. Uppercase Space Grotesk label in a colored chip.
 * Use for product status (NEW, SALE), category tags, and status indicators.
 */
export function Badge({
  variant = 'primary',
  size = 'md',
  outline = false,
  children,
}) {
  const colorMap = {
    primary:   ['var(--color-primary)',   'var(--color-primary-content)'],
    secondary: ['var(--color-secondary)', '#ffffff'],
    accent:    ['var(--color-accent)',    'var(--color-accent-content)'],
    neutral:   ['var(--color-neutral)',   'var(--color-neutral-content)'],
    success:   ['var(--color-success)',   'var(--color-success-content)'],
    warning:   ['var(--color-warning)',   'var(--color-warning-content)'],
    error:     ['var(--color-error)',     'var(--color-error-content)'],
    info:      ['var(--color-info)',      'var(--color-info-content)'],
    ghost:     ['var(--color-base-content)', 'var(--color-base-100)'],
  };

  const sizeMap = {
    sm: ['0.15rem 0.45rem', '0.625rem'],
    md: ['0.2rem  0.6rem',  '0.6875rem'],
    lg: ['0.3rem  0.8rem',  '0.8125rem'],
  };

  const [bg, fg] = colorMap[variant] || colorMap.primary;
  const [padding, fontSize] = sizeMap[size] || sizeMap.md;

  const style = {
    display: 'inline-flex',
    alignItems: 'center',
    padding,
    fontSize,
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    borderRadius: 'var(--radius-selector, 0.25rem)',
    lineHeight: 1,
    background: outline ? 'transparent' : bg,
    color: outline ? bg : fg,
    border: `1.5px solid ${bg}`,
  };

  return <span style={style}>{children}</span>;
}
