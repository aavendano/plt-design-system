/**
 * E-commerce product card with square image, title, price, badge and optional CTA.
 * Neo-brutalista border + hard offset shadow with hover lift.
 */
export interface ProductCardProps {
  /** Product display name (renders in Fjalla One uppercase) */
  title?: string;
  /** Formatted price string, e.g. "$99.00" */
  price?: string;
  /** Original price for sale items (shows with strikethrough) */
  originalPrice?: string;
  /** Image URL. Falls back to picsum.photos placeholder if omitted. */
  image?: string;
  /** Short badge label shown over image (e.g. "NEW", "SALE") */
  badge?: string;
  /** Link href for the card */
  href?: string;
  /** If provided, renders an "Add to Cart" button and calls this on click */
  onAddToCart?: () => void;
}

export declare function ProductCard(props: ProductCardProps): JSX.Element;
