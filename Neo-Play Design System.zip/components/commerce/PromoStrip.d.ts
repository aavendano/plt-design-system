/**
 * Full-width promotional announcement strip.
 * Place above the Navbar or at the top of hero sections.
 */
export interface PromoStripProps {
  /** Announcement message */
  message?: string;
  /** Optional CTA link label (renders underlined inline) */
  ctaLabel?: string;
  /** CTA link href */
  ctaHref?: string;
  /** Material Symbol icon name shown before the message */
  icon?: string;
  /** Color variant */
  variant?: 'primary' | 'secondary' | 'neutral' | 'warning';
}

export declare function PromoStrip(props: PromoStripProps): JSX.Element;
