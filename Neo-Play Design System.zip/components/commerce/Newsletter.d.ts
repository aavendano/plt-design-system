/**
 * Email newsletter signup section. Warm yellow background, heavy border, email + CTA.
 */
export interface NewsletterProps {
  /** Section headline (renders in Fjalla One uppercase) */
  heading?: string;
  /** Supporting subheading */
  subheading?: string;
  /** Email input placeholder */
  placeholder?: string;
  /** Submit button label */
  ctaLabel?: string;
  /** Called with email value on submit */
  onSubmit?: (email: string) => void;
}

export declare function Newsletter(props: NewsletterProps): JSX.Element;
