import React from 'react';

/**
 * Email newsletter signup section. Warning (warm yellow) background,
 * heavy border top/bottom, side-by-side email + submit.
 */
export function Newsletter({
  heading = 'Stay in the loop',
  subheading = 'New drops, exclusive deals, zero spam.',
  placeholder = 'Your email address',
  ctaLabel = 'Subscribe',
  onSubmit,
}) {
  const [email, setEmail] = React.useState('');
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (onSubmit) onSubmit(email);
    setSubmitted(true);
  };

  const sectionStyle = {
    background: 'var(--color-warning)',
    borderTop: '3px solid var(--color-base-content)',
    borderBottom: '3px solid var(--color-base-content)',
    padding: 'clamp(3rem, 6vw, 5rem) clamp(1.5rem, 4vw, 3rem)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '1.5rem',
    textAlign: 'center',
    width: '100%',
    boxSizing: 'border-box',
  };

  const headingStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: 'clamp(2rem, 4vw, 3rem)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '-0.02em',
    color: 'var(--color-base-content)',
    lineHeight: 1.1,
    margin: 0,
  };

  const subStyle = {
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    fontSize: '1.0625rem',
    color: 'var(--color-base-content)',
    opacity: 0.7,
    margin: 0,
    maxWidth: '28rem',
    lineHeight: 1.5,
  };

  const formStyle = {
    display: 'flex',
    width: '100%',
    maxWidth: '28rem',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    overflow: 'hidden',
    boxShadow: '3px 3px 0 0 var(--color-base-content)',
  };

  const inputStyle = {
    flex: 1,
    padding: '0.75rem 1rem',
    fontSize: '0.9375rem',
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    border: 'none',
    outline: 'none',
    background: '#fff',
    color: 'var(--color-base-content)',
    minWidth: 0,
  };

  const submitStyle = {
    padding: '0.75rem 1.375rem',
    background: 'var(--color-primary)',
    color: 'var(--color-primary-content)',
    border: 'none',
    borderLeft: '1.5px solid var(--color-base-content)',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    cursor: 'pointer',
    whiteSpace: 'nowrap',
    flexShrink: 0,
  };

  if (submitted) {
    return (
      <div style={sectionStyle}>
        <p style={{ ...headingStyle, fontSize: 'clamp(1.5rem, 3vw, 2rem)' }}>You&rsquo;re in ✓</p>
        <p style={subStyle}>Thanks for subscribing. Watch your inbox.</p>
      </div>
    );
  }

  return (
    <div style={sectionStyle}>
      <h2 style={headingStyle}>{heading}</h2>
      <p style={subStyle}>{subheading}</p>
      <form style={formStyle} onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder={placeholder}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={inputStyle}
        />
        <button type="submit" style={submitStyle}>{ctaLabel}</button>
      </form>
    </div>
  );
}
