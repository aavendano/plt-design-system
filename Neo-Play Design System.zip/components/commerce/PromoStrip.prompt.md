Use `PromoStrip` for site-wide announcements — free shipping thresholds, sale events, new collection launches. Place above the `Navbar` for maximum visibility.

```jsx
// Free shipping (most common)
<PromoStrip
  message="Free shipping on orders over $75"
  icon="local_shipping"
  variant="primary"
/>

// Sale event
<PromoStrip
  message="Summer Sale — Up to 40% off"
  ctaLabel="Shop Now"
  ctaHref="/sale"
  icon="sell"
  variant="secondary"
/>

// Neutral announcement
<PromoStrip
  message="New collection dropping Friday"
  ctaLabel="Get Notified"
  variant="neutral"
  icon="notifications"
/>
```

**Placement:** PromoStrip → Navbar → page content

Icon accepts any Material Symbol name. Omit `icon` prop to hide it. Omit `ctaLabel` for a message-only strip.
