import React from 'react';

/**
 * Full-width promotional announcement strip.
 * Primary (purple) or secondary (rose) background with optional icon + CTA.
 * Typically placed at the very top of the page, above the Navbar.
 */
export function PromoStrip({
  message = 'Free shipping on orders over $75',
  ctaLabel,
  ctaHref = '#',
  icon = 'local_shipping',
  variant = 'primary',
}) {
  const variantStyles = {
    primary:   { background: 'var(--color-primary)',   color: 'var(--color-primary-content)' },
    secondary: { background: 'var(--color-secondary)', color: '#ffffff' },
    neutral:   { background: 'var(--color-neutral)',   color: 'var(--color-neutral-content)' },
    warning:   { background: 'var(--color-warning)',   color: 'var(--color-warning-content)' },
  };
  const v = variantStyles[variant] || variantStyles.primary;

  const stripStyle = {
    ...v,
    padding: '0.625rem 1.5rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.625rem',
    width: '100%',
    boxSizing: 'border-box',
    borderBottom: '1.5px solid var(--color-base-content)',
  };

  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '17px',
    lineHeight: 1,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
  };

  const textStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 600,
    letterSpacing: '0.03em',
  };

  const ctaStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.75rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'inherit',
    textDecoration: 'underline',
    textUnderlineOffset: '2px',
    cursor: 'pointer',
    flexShrink: 0,
  };

  return (
    <div style={stripStyle} role="banner">
      {icon && <span style={iconStyle}>{icon}</span>}
      <span style={textStyle}>{message}</span>
      {ctaLabel && (
        <a href={ctaHref} style={ctaStyle}>{ctaLabel}</a>
      )}
    </div>
  );
}
