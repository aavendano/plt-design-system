Use `Newsletter` as a standalone full-width section, typically between products and footer. Shows warm yellow background with heavy borders.

```jsx
// Default
<Newsletter />

// Custom copy
<Newsletter
  heading="Join the community"
  subheading="First access to new drops and exclusive member pricing."
  ctaLabel="Join Now"
  onSubmit={(email) => subscribe(email)}
/>
```

After submit, the component replaces itself with a confirmation message. For production, wire `onSubmit` to your email service API.
