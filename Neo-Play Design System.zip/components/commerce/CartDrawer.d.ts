/**
 * Slide-in cart panel with item list, qty controls, subtotal, and checkout button.
 * Mount once at the root level; control open/close via `isOpen`.
 */
export interface CartDrawerProps {
  /** Whether the drawer is visible */
  isOpen?: boolean;
  /** Called when overlay or close button is clicked */
  onClose?: () => void;
  /** Array of cart line items */
  items?: Array<{
    /** Product name */
    name: string;
    /** Formatted price string, e.g. "$49.00" */
    price: string;
    /** Quantity (defaults to 1) */
    qty?: number;
    /** Variant label, e.g. "Size: M / Color: Black" */
    variant?: string;
    /** Product image URL */
    image?: string;
  }>;
  /** Called with (item, newQty) when +/− is clicked */
  onUpdateQty?: (item: object, newQty: number) => void;
  /** Called with item when the remove button is clicked */
  onRemove?: (item: object) => void;
  /** Called when Checkout button is clicked */
  onCheckout?: () => void;
}

export declare function CartDrawer(props: CartDrawerProps): JSX.Element;
