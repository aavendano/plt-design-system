import React from 'react';

/**
 * Slide-in cart drawer panel. Fixed right side, semi-transparent backdrop,
 * smooth translateX transition. Lists items with qty controls.
 */
export function CartDrawer({
  isOpen = false,
  onClose,
  items = [],
  onUpdateQty,
  onRemove,
  onCheckout,
}) {
  const subtotal = items.reduce((sum, item) => {
    const price = parseFloat(String(item.price || '0').replace(/[^0-9.]/g, ''));
    return sum + (isNaN(price) ? 0 : price) * (item.qty || 1);
  }, 0);

  const overlayStyle = {
    position: 'fixed',
    inset: 0,
    background: 'rgba(0,0,0,0.35)',
    zIndex: 99,
    opacity: isOpen ? 1 : 0,
    pointerEvents: isOpen ? 'all' : 'none',
    transition: 'opacity 250ms ease',
  };

  const drawerStyle = {
    position: 'fixed',
    top: 0,
    right: 0,
    bottom: 0,
    width: '100%',
    maxWidth: '28rem',
    background: 'var(--color-base-100)',
    borderLeft: '3px solid var(--color-base-content)',
    zIndex: 100,
    display: 'flex',
    flexDirection: 'column',
    transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
    transition: 'transform 250ms cubic-bezier(0.22, 1, 0.36, 1)',
    overflowY: 'hidden',
  };

  const headerStyle = {
    padding: '1.25rem 1.5rem',
    borderBottom: '1.5px solid var(--color-base-content)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexShrink: 0,
  };

  const titleStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '1.25rem',
    textTransform: 'uppercase',
    fontWeight: 700,
    color: 'var(--color-base-content)',
    margin: 0,
    letterSpacing: '-0.01em',
  };

  const closeBtnStyle = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '24px',
    color: 'var(--color-base-content)',
    padding: '4px',
    borderRadius: '0.25rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
  };

  const itemsStyle = {
    flex: 1,
    overflowY: 'auto',
    padding: '1rem 1.5rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  };

  const emptyStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    gap: '1rem',
    padding: '2rem',
  };

  const emptyIconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '52px',
    color: 'var(--color-base-content)',
    opacity: 0.2,
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
  };

  const footerStyle = {
    padding: '1.25rem 1.5rem',
    borderTop: '1.5px solid var(--color-base-content)',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.875rem',
    flexShrink: 0,
  };

  const subtotalRowStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline',
  };

  const subtotalLabelStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)',
  };

  const subtotalValueStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '1.25rem',
    fontWeight: 700,
    color: 'var(--color-base-content)',
  };

  const checkoutStyle = {
    width: '100%',
    padding: '0.875rem',
    background: 'var(--color-primary)',
    color: 'var(--color-primary-content)',
    border: '1.5px solid var(--color-primary)',
    borderRadius: '0.25rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.9375rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    cursor: 'pointer',
    boxShadow: '3px 3px 0 0 var(--color-base-content)',
  };

  return (
    <>
      <div style={overlayStyle} onClick={onClose} aria-hidden="true" />
      <aside
        style={drawerStyle}
        aria-label="Shopping cart"
        aria-hidden={!isOpen}
        role="dialog"
        aria-modal="true"
      >
        <div style={headerStyle}>
          <h2 style={titleStyle}>
            Your Cart{items.length > 0 ? ` (${items.length})` : ''}
          </h2>
          <button style={closeBtnStyle} onClick={onClose} aria-label="Close cart">close</button>
        </div>

        {items.length === 0 ? (
          <div style={emptyStyle}>
            <span style={emptyIconStyle}>shopping_bag</span>
            <p style={{
              fontFamily: 'var(--font-body)',
              fontSize: '1rem',
              color: 'var(--color-base-content)',
              opacity: 0.5,
              margin: 0,
              textAlign: 'center',
            }}>Your cart is empty.</p>
          </div>
        ) : (
          <>
            <div style={itemsStyle}>
              {items.map((item, i) => (
                <CartItem key={i} item={item} onUpdateQty={onUpdateQty} onRemove={onRemove} />
              ))}
            </div>
            <div style={footerStyle}>
              <div style={subtotalRowStyle}>
                <span style={subtotalLabelStyle}>Subtotal</span>
                <span style={subtotalValueStyle}>${subtotal.toFixed(2)}</span>
              </div>
              <button style={checkoutStyle} onClick={onCheckout}>Proceed to Checkout</button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}

function CartItem({ item, onUpdateQty, onRemove }) {
  const rowStyle = {
    display: 'flex',
    gap: '0.875rem',
    paddingBottom: '1rem',
    borderBottom: '1px solid var(--color-base-300)',
  };

  const imgStyle = {
    width: '76px',
    height: '76px',
    objectFit: 'cover',
    borderRadius: '0.25rem',
    border: '1.5px solid var(--color-base-content)',
    flexShrink: 0,
    display: 'block',
    background: 'var(--color-base-300)',
  };

  const infoStyle = {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: '0.25rem',
    minWidth: 0,
  };

  const nameStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '0.9375rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    color: 'var(--color-base-content)',
    lineHeight: 1.25,
    margin: 0,
  };

  const variantTextStyle = {
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    fontSize: '0.8125rem',
    color: 'var(--color-base-content)',
    opacity: 0.6,
  };

  const qtyRowStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    marginTop: 'auto',
  };

  const qtyBtnStyle = {
    width: '26px',
    height: '26px',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    background: 'var(--color-base-100)',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'var(--font-accent)',
    fontSize: '1rem',
    fontWeight: 700,
    color: 'var(--color-base-content)',
    lineHeight: 1,
    padding: 0,
  };

  const priceStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.9375rem',
    fontWeight: 700,
    color: 'var(--color-base-content)',
    marginLeft: 'auto',
    alignSelf: 'flex-end',
  };

  const removeBtnStyle = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '16px',
    color: 'var(--color-base-content)',
    opacity: 0.45,
    padding: 0,
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
  };

  return (
    <div style={rowStyle}>
      {item.image
        ? <img src={item.image} alt={item.name} style={imgStyle} />
        : <div style={imgStyle} />
      }
      <div style={infoStyle}>
        <p style={nameStyle}>{item.name}</p>
        {item.variant && <span style={variantTextStyle}>{item.variant}</span>}
        <div style={qtyRowStyle}>
          <button style={qtyBtnStyle} onClick={() => onUpdateQty && onUpdateQty(item, (item.qty || 1) - 1)}>−</button>
          <span style={{ fontFamily: 'var(--font-accent)', fontSize: '0.9375rem', fontWeight: 700, minWidth: '1.5rem', textAlign: 'center' }}>
            {item.qty || 1}
          </span>
          <button style={qtyBtnStyle} onClick={() => onUpdateQty && onUpdateQty(item, (item.qty || 1) + 1)}>+</button>
          <button style={removeBtnStyle} onClick={() => onRemove && onRemove(item)} aria-label="Remove item">close</button>
        </div>
        <span style={priceStyle}>{item.price}</span>
      </div>
    </div>
  );
}
