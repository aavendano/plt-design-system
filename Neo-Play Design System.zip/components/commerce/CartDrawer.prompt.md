Mount `CartDrawer` once at the root of your layout. Control it via a shared state variable and wire `Navbar`'s `onCartClick` to open it.

```jsx
function Layout({ children }) {
  const [cartOpen, setCartOpen] = React.useState(false);
  const [cartItems, setCartItems] = React.useState([
    { name: 'Premium Hoodie', price: '$89.00', qty: 1, variant: 'Size: L / Color: Black' },
    { name: 'Canvas Cap',     price: '$42.00', qty: 2 },
  ]);

  const handleUpdateQty = (item, qty) => {
    if (qty < 1) handleRemove(item);
    else setCartItems(prev => prev.map(i => i === item ? { ...i, qty } : i));
  };
  const handleRemove = (item) => setCartItems(prev => prev.filter(i => i !== item));

  return (
    <>
      <Navbar cartCount={cartItems.length} onCartClick={() => setCartOpen(true)} />
      {children}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQty={handleUpdateQty}
        onRemove={handleRemove}
        onCheckout={() => window.location.href = '/checkout'}
      />
    </>
  );
}
```

The backdrop click also closes the drawer. Subtotal is computed automatically from `item.price × item.qty`.
