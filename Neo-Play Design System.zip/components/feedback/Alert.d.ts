/**
 * Inline semantic alert block with icon, optional title, and body text.
 */
export interface AlertProps {
  /** Semantic variant */
  variant?: 'info' | 'success' | 'warning' | 'error';
  /** Bold uppercase title line (optional) */
  title?: string;
  /** Alert body content */
  children?: React.ReactNode;
}

export declare function Alert(props: AlertProps): JSX.Element;
