/**
 * Notification toast with semantic color, icon, and optional auto-dismiss.
 * Wrap in a fixed bottom-right container for page-level notifications.
 */
export interface ToastProps {
  /** Semantic variant (controls color + icon) */
  variant?: 'info' | 'success' | 'warning' | 'error';
  /** Notification message */
  message?: string;
  /** Called when dismissed (also shows close button) */
  onDismiss?: () => void;
  /** Auto-dismiss after this many milliseconds */
  duration?: number;
}

export declare function Toast(props: ToastProps): JSX.Element;
