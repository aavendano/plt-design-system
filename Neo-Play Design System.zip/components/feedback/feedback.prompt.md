# Feedback Components

Use `Toast` for ephemeral page-level notifications and `Alert` for inline persistent messages inside forms or content areas.

## Toast

```jsx
// Page-level notification (mount at root)
<div style={{ position: 'fixed', bottom: '1.5rem', right: '1.5rem', zIndex: 200 }}>
  <Toast variant="success" message="Added to cart!" onDismiss={() => setToast(null)} duration={4000} />
</div>

// Error
<Toast variant="error" message="Something went wrong. Please try again." onDismiss={dismiss} />

// Info without auto-dismiss
<Toast variant="info" message="Your order is being processed." />
```

## Alert

```jsx
// Checkout warning
<Alert variant="warning" title="Address incomplete">
  Please add a zip code before continuing.
</Alert>

// Order confirmation
<Alert variant="success" title="Order placed!">
  Check your email for a confirmation and tracking link.
</Alert>

// Form error
<Alert variant="error">
  We couldn't process your payment. Please check your card details.
</Alert>
```

**Variants:** `info` · `success` · `warning` · `error`

`Toast` auto-dismisses after `duration` ms; `Alert` is always visible. Both include a semantic icon auto-selected from Material Symbols Outlined.
