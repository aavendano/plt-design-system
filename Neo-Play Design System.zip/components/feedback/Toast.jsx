import React from 'react';

/**
 * Notification toast. Hard-shadow chip with semantic color and icon.
 * Self-dismisses after `duration` ms if provided.
 */
export function Toast({
  variant = 'info',
  message = 'Something happened.',
  onDismiss,
  duration,
}) {
  const [visible, setVisible] = React.useState(true);

  React.useEffect(() => {
    if (!duration) return;
    const t = setTimeout(() => {
      setVisible(false);
      if (onDismiss) onDismiss();
    }, duration);
    return () => clearTimeout(t);
  }, [duration]);

  if (!visible) return null;

  const configs = {
    info:    { bg: 'var(--color-info)',    fg: 'var(--color-info-content)',    icon: 'info' },
    success: { bg: 'var(--color-success)', fg: 'var(--color-success-content)', icon: 'check_circle' },
    warning: { bg: 'var(--color-warning)', fg: 'var(--color-warning-content)', icon: 'warning' },
    error:   { bg: 'var(--color-error)',   fg: 'var(--color-error-content)',   icon: 'error' },
  };
  const c = configs[variant] || configs.info;

  const toastStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0.875rem 1rem',
    background: c.bg,
    color: c.fg,
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    boxShadow: '3px 3px 0 0 var(--color-base-content)',
    maxWidth: '24rem',
    width: '100%',
    boxSizing: 'border-box',
  };

  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '20px',
    lineHeight: 1,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
  };

  const closeBtnStyle = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '18px',
    color: 'inherit',
    opacity: 0.65,
    padding: 0,
    lineHeight: 1,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
  };

  return (
    <div style={toastStyle} role="alert">
      <span style={iconStyle}>{c.icon}</span>
      <span style={{
        fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
        fontSize: '0.9375rem',
        lineHeight: 1.4,
        flex: 1,
      }}>{message}</span>
      {onDismiss && (
        <button
          style={closeBtnStyle}
          onClick={() => { setVisible(false); onDismiss(); }}
          aria-label="Dismiss"
        >close</button>
      )}
    </div>
  );
}
