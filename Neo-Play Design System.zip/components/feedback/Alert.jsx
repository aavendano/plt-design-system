import React from 'react';

/**
 * Inline alert block. Semantic background color with icon and optional title.
 * Use inside forms, checkout flows, and content areas.
 */
export function Alert({
  variant = 'info',
  title,
  children,
}) {
  const configs = {
    info:    { bg: 'var(--color-info)',    fg: 'var(--color-info-content)',    icon: 'info' },
    success: { bg: 'var(--color-success)', fg: 'var(--color-success-content)', icon: 'check_circle' },
    warning: { bg: 'var(--color-warning)', fg: 'var(--color-base-content)',    icon: 'warning' },
    error:   { bg: 'var(--color-error)',   fg: 'var(--color-error-content)',   icon: 'error' },
  };
  const c = configs[variant] || configs.info;

  const alertStyle = {
    display: 'flex',
    gap: '0.75rem',
    padding: '1rem 1.25rem',
    background: c.bg,
    color: c.fg,
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    width: '100%',
    boxSizing: 'border-box',
  };

  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '20px',
    lineHeight: 1.35,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
  };

  return (
    <div style={alertStyle} role="alert">
      <span style={iconStyle}>{c.icon}</span>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem', flex: 1 }}>
        {title && (
          <span style={{
            fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
            fontSize: '0.875rem',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.04em',
          }}>{title}</span>
        )}
        {children && (
          <p style={{
            fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
            fontSize: '0.9375rem',
            lineHeight: 1.5,
            opacity: 0.85,
            margin: 0,
          }}>{children}</p>
        )}
      </div>
    </div>
  );
}
