/* @ds-bundle: {"format":4,"namespace":"NeoPlayDesignSystem_3742b6","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"CartDrawer","sourcePath":"components/commerce/CartDrawer.jsx"},{"name":"Newsletter","sourcePath":"components/commerce/Newsletter.jsx"},{"name":"PromoStrip","sourcePath":"components/commerce/PromoStrip.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"ProductCard","sourcePath":"components/data-display/ProductCard.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Navbar","sourcePath":"components/navigation/Navbar.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"02b00eee06a6","components/commerce/CartDrawer.jsx":"2e4fc0ab1ce4","components/commerce/Newsletter.jsx":"bb09715b1ad7","components/commerce/PromoStrip.jsx":"987ab0acc939","components/data-display/Badge.jsx":"1f46743b7a18","components/data-display/ProductCard.jsx":"77a564f105a7","components/feedback/Alert.jsx":"c97989ede0aa","components/feedback/Toast.jsx":"e41a00821421","components/forms/Checkbox.jsx":"56b4e9b6c9fa","components/forms/Input.jsx":"a616906b37d8","components/forms/Select.jsx":"0c17924f3525","components/navigation/Navbar.jsx":"dd2cd6da315f","guidelines/doc-page.js":"f52ae9c02fca","guidelines/tweaks-panel.jsx":"d259e3a86f73"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NeoPlayDesignSystem_3742b6 = window.NeoPlayDesignSystem_3742b6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
/**
 * Neo-Play primary action button. Neo-brutalista style: bold uppercase labels,
 * hard offset shadow on hover, subtle press animation.
 */
function Button({
  variant = 'primary',
  size = 'md',
  children,
  disabled = false,
  onClick,
  fullWidth = false,
  icon,
  iconPosition = 'left',
  elevated = false,
  type = 'button'
}) {
  const [hovered, setHovered] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);
  const variantStyles = {
    primary: {
      background: 'var(--color-primary)',
      color: 'var(--color-primary-content)',
      border: '3px solid var(--color-primary)'
    },
    secondary: {
      background: 'var(--color-secondary)',
      color: '#ffffff',
      border: '3px solid var(--color-secondary)'
    },
    accent: {
      background: 'var(--color-accent)',
      color: 'var(--color-accent-content)',
      border: '3px solid var(--color-accent)'
    },
    neutral: {
      background: 'var(--color-neutral)',
      color: 'var(--color-neutral-content)',
      border: '3px solid var(--color-neutral)'
    },
    warning: {
      background: 'var(--color-warning)',
      color: 'var(--color-warning-content)',
      border: '3px solid var(--color-base-content)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--color-base-content)',
      border: '3px solid var(--color-base-content)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--color-base-content)',
      border: '3px solid transparent'
    }
  };
  const sizeStyles = {
    sm: {
      padding: '0.375rem 0.875rem',
      fontSize: '0.75rem',
      iconSize: '16px',
      gap: '0.375rem'
    },
    md: {
      padding: '0.625rem 1.25rem',
      fontSize: '0.8125rem',
      iconSize: '18px',
      gap: '0.5rem'
    },
    lg: {
      padding: '0.875rem 1.75rem',
      fontSize: '0.9375rem',
      iconSize: '20px',
      gap: '0.5rem'
    },
    xl: {
      padding: '1.125rem 2.25rem',
      fontSize: '1.0625rem',
      iconSize: '22px',
      gap: '0.625rem'
    }
  };
  const v = variantStyles[variant] || variantStyles.primary;
  const s = sizeStyles[size] || sizeStyles.md;
  const isActive = !disabled;
  const transform = !isActive ? 'none' : pressed ? 'translateY(2px)' : hovered ? 'translateY(-2px)' : 'none';
  const boxShadow = !isActive || pressed ? 'none' : hovered ? '3px 3px 0 0 var(--color-base-content)' : elevated ? '2px 2px 0 0 var(--color-base-content)' : 'none';
  const style = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    borderRadius: 'var(--radius-field, 0.25rem)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    width: fullWidth ? '100%' : 'auto',
    transition: 'transform 150ms ease, box-shadow 150ms ease',
    transform,
    boxShadow,
    whiteSpace: 'nowrap',
    userSelect: 'none',
    textDecoration: 'none',
    lineHeight: 1.2,
    ...v
  };
  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontWeight: 'normal',
    fontStyle: 'normal',
    fontSize: s.iconSize,
    lineHeight: 1,
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block',
    flexShrink: 0
  };
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    style: style,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => {
      setHovered(false);
      setPressed(false);
    },
    onMouseDown: () => setPressed(true),
    onMouseUp: () => setPressed(false)
  }, icon && iconPosition === 'left' && /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, icon), children, icon && iconPosition === 'right' && /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, icon));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/commerce/CartDrawer.jsx
try { (() => {
/**
 * Slide-in cart drawer panel. Fixed right side, semi-transparent backdrop,
 * smooth translateX transition. Lists items with qty controls.
 */
function CartDrawer({
  isOpen = false,
  onClose,
  items = [],
  onUpdateQty,
  onRemove,
  onCheckout
}) {
  const subtotal = items.reduce((sum, item) => {
    const price = parseFloat(String(item.price || '0').replace(/[^0-9.]/g, ''));
    return sum + (isNaN(price) ? 0 : price) * (item.qty || 1);
  }, 0);
  const overlayStyle = {
    position: 'fixed',
    inset: 0,
    background: 'rgba(0,0,0,0.35)',
    zIndex: 99,
    opacity: isOpen ? 1 : 0,
    pointerEvents: isOpen ? 'all' : 'none',
    transition: 'opacity 250ms ease'
  };
  const drawerStyle = {
    position: 'fixed',
    top: 0,
    right: 0,
    bottom: 0,
    width: '100%',
    maxWidth: '28rem',
    background: 'var(--color-base-100)',
    borderLeft: '3px solid var(--color-base-content)',
    zIndex: 100,
    display: 'flex',
    flexDirection: 'column',
    transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
    transition: 'transform 250ms cubic-bezier(0.22, 1, 0.36, 1)',
    overflowY: 'hidden'
  };
  const headerStyle = {
    padding: '1.25rem 1.5rem',
    borderBottom: '1.5px solid var(--color-base-content)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexShrink: 0
  };
  const titleStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '1.25rem',
    textTransform: 'uppercase',
    fontWeight: 700,
    color: 'var(--color-base-content)',
    margin: 0,
    letterSpacing: '-0.01em'
  };
  const closeBtnStyle = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '24px',
    color: 'var(--color-base-content)',
    padding: '4px',
    borderRadius: '0.25rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none'
  };
  const itemsStyle = {
    flex: 1,
    overflowY: 'auto',
    padding: '1rem 1.5rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem'
  };
  const emptyStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    gap: '1rem',
    padding: '2rem'
  };
  const emptyIconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '52px',
    color: 'var(--color-base-content)',
    opacity: 0.2,
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none'
  };
  const footerStyle = {
    padding: '1.25rem 1.5rem',
    borderTop: '1.5px solid var(--color-base-content)',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.875rem',
    flexShrink: 0
  };
  const subtotalRowStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline'
  };
  const subtotalLabelStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)'
  };
  const subtotalValueStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '1.25rem',
    fontWeight: 700,
    color: 'var(--color-base-content)'
  };
  const checkoutStyle = {
    width: '100%',
    padding: '0.875rem',
    background: 'var(--color-primary)',
    color: 'var(--color-primary-content)',
    border: '1.5px solid var(--color-primary)',
    borderRadius: '0.25rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.9375rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    cursor: 'pointer',
    boxShadow: '3px 3px 0 0 var(--color-base-content)'
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: overlayStyle,
    onClick: onClose,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("aside", {
    style: drawerStyle,
    "aria-label": "Shopping cart",
    "aria-hidden": !isOpen,
    role: "dialog",
    "aria-modal": "true"
  }, /*#__PURE__*/React.createElement("div", {
    style: headerStyle
  }, /*#__PURE__*/React.createElement("h2", {
    style: titleStyle
  }, "Your Cart", items.length > 0 ? ` (${items.length})` : ''), /*#__PURE__*/React.createElement("button", {
    style: closeBtnStyle,
    onClick: onClose,
    "aria-label": "Close cart"
  }, "close")), items.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: emptyStyle
  }, /*#__PURE__*/React.createElement("span", {
    style: emptyIconStyle
  }, "shopping_bag"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: '1rem',
      color: 'var(--color-base-content)',
      opacity: 0.5,
      margin: 0,
      textAlign: 'center'
    }
  }, "Your cart is empty.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: itemsStyle
  }, items.map((item, i) => /*#__PURE__*/React.createElement(CartItem, {
    key: i,
    item: item,
    onUpdateQty: onUpdateQty,
    onRemove: onRemove
  }))), /*#__PURE__*/React.createElement("div", {
    style: footerStyle
  }, /*#__PURE__*/React.createElement("div", {
    style: subtotalRowStyle
  }, /*#__PURE__*/React.createElement("span", {
    style: subtotalLabelStyle
  }, "Subtotal"), /*#__PURE__*/React.createElement("span", {
    style: subtotalValueStyle
  }, "$", subtotal.toFixed(2))), /*#__PURE__*/React.createElement("button", {
    style: checkoutStyle,
    onClick: onCheckout
  }, "Proceed to Checkout")))));
}
function CartItem({
  item,
  onUpdateQty,
  onRemove
}) {
  const rowStyle = {
    display: 'flex',
    gap: '0.875rem',
    paddingBottom: '1rem',
    borderBottom: '1px solid var(--color-base-300)'
  };
  const imgStyle = {
    width: '76px',
    height: '76px',
    objectFit: 'cover',
    borderRadius: '0.25rem',
    border: '1.5px solid var(--color-base-content)',
    flexShrink: 0,
    display: 'block',
    background: 'var(--color-base-300)'
  };
  const infoStyle = {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: '0.25rem',
    minWidth: 0
  };
  const nameStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '0.9375rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    color: 'var(--color-base-content)',
    lineHeight: 1.25,
    margin: 0
  };
  const variantTextStyle = {
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    fontSize: '0.8125rem',
    color: 'var(--color-base-content)',
    opacity: 0.6
  };
  const qtyRowStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    marginTop: 'auto'
  };
  const qtyBtnStyle = {
    width: '26px',
    height: '26px',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    background: 'var(--color-base-100)',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'var(--font-accent)',
    fontSize: '1rem',
    fontWeight: 700,
    color: 'var(--color-base-content)',
    lineHeight: 1,
    padding: 0
  };
  const priceStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.9375rem',
    fontWeight: 700,
    color: 'var(--color-base-content)',
    marginLeft: 'auto',
    alignSelf: 'flex-end'
  };
  const removeBtnStyle = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '16px',
    color: 'var(--color-base-content)',
    opacity: 0.45,
    padding: 0,
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: rowStyle
  }, item.image ? /*#__PURE__*/React.createElement("img", {
    src: item.image,
    alt: item.name,
    style: imgStyle
  }) : /*#__PURE__*/React.createElement("div", {
    style: imgStyle
  }), /*#__PURE__*/React.createElement("div", {
    style: infoStyle
  }, /*#__PURE__*/React.createElement("p", {
    style: nameStyle
  }, item.name), item.variant && /*#__PURE__*/React.createElement("span", {
    style: variantTextStyle
  }, item.variant), /*#__PURE__*/React.createElement("div", {
    style: qtyRowStyle
  }, /*#__PURE__*/React.createElement("button", {
    style: qtyBtnStyle,
    onClick: () => onUpdateQty && onUpdateQty(item, (item.qty || 1) - 1)
  }, "\u2212"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-accent)',
      fontSize: '0.9375rem',
      fontWeight: 700,
      minWidth: '1.5rem',
      textAlign: 'center'
    }
  }, item.qty || 1), /*#__PURE__*/React.createElement("button", {
    style: qtyBtnStyle,
    onClick: () => onUpdateQty && onUpdateQty(item, (item.qty || 1) + 1)
  }, "+"), /*#__PURE__*/React.createElement("button", {
    style: removeBtnStyle,
    onClick: () => onRemove && onRemove(item),
    "aria-label": "Remove item"
  }, "close")), /*#__PURE__*/React.createElement("span", {
    style: priceStyle
  }, item.price)));
}
Object.assign(__ds_scope, { CartDrawer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/CartDrawer.jsx", error: String((e && e.message) || e) }); }

// components/commerce/Newsletter.jsx
try { (() => {
/**
 * Email newsletter signup section. Warning (warm yellow) background,
 * heavy border top/bottom, side-by-side email + submit.
 */
function Newsletter({
  heading = 'Stay in the loop',
  subheading = 'New drops, exclusive deals, zero spam.',
  placeholder = 'Your email address',
  ctaLabel = 'Subscribe',
  onSubmit
}) {
  const [email, setEmail] = React.useState('');
  const [submitted, setSubmitted] = React.useState(false);
  const handleSubmit = e => {
    e.preventDefault();
    if (onSubmit) onSubmit(email);
    setSubmitted(true);
  };
  const sectionStyle = {
    background: 'var(--color-warning)',
    borderTop: '3px solid var(--color-base-content)',
    borderBottom: '3px solid var(--color-base-content)',
    padding: 'clamp(3rem, 6vw, 5rem) clamp(1.5rem, 4vw, 3rem)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '1.5rem',
    textAlign: 'center',
    width: '100%',
    boxSizing: 'border-box'
  };
  const headingStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: 'clamp(2rem, 4vw, 3rem)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '-0.02em',
    color: 'var(--color-base-content)',
    lineHeight: 1.1,
    margin: 0
  };
  const subStyle = {
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    fontSize: '1.0625rem',
    color: 'var(--color-base-content)',
    opacity: 0.7,
    margin: 0,
    maxWidth: '28rem',
    lineHeight: 1.5
  };
  const formStyle = {
    display: 'flex',
    width: '100%',
    maxWidth: '28rem',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    overflow: 'hidden',
    boxShadow: '3px 3px 0 0 var(--color-base-content)'
  };
  const inputStyle = {
    flex: 1,
    padding: '0.75rem 1rem',
    fontSize: '0.9375rem',
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    border: 'none',
    outline: 'none',
    background: '#fff',
    color: 'var(--color-base-content)',
    minWidth: 0
  };
  const submitStyle = {
    padding: '0.75rem 1.375rem',
    background: 'var(--color-primary)',
    color: 'var(--color-primary-content)',
    border: 'none',
    borderLeft: '1.5px solid var(--color-base-content)',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    cursor: 'pointer',
    whiteSpace: 'nowrap',
    flexShrink: 0
  };
  if (submitted) {
    return /*#__PURE__*/React.createElement("div", {
      style: sectionStyle
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        ...headingStyle,
        fontSize: 'clamp(1.5rem, 3vw, 2rem)'
      }
    }, "You\u2019re in \u2713"), /*#__PURE__*/React.createElement("p", {
      style: subStyle
    }, "Thanks for subscribing. Watch your inbox."));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: sectionStyle
  }, /*#__PURE__*/React.createElement("h2", {
    style: headingStyle
  }, heading), /*#__PURE__*/React.createElement("p", {
    style: subStyle
  }, subheading), /*#__PURE__*/React.createElement("form", {
    style: formStyle,
    onSubmit: handleSubmit
  }, /*#__PURE__*/React.createElement("input", {
    type: "email",
    placeholder: placeholder,
    value: email,
    onChange: e => setEmail(e.target.value),
    required: true,
    style: inputStyle
  }), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    style: submitStyle
  }, ctaLabel)));
}
Object.assign(__ds_scope, { Newsletter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/Newsletter.jsx", error: String((e && e.message) || e) }); }

// components/commerce/PromoStrip.jsx
try { (() => {
/**
 * Full-width promotional announcement strip.
 * Primary (purple) or secondary (rose) background with optional icon + CTA.
 * Typically placed at the very top of the page, above the Navbar.
 */
function PromoStrip({
  message = 'Free shipping on orders over $75',
  ctaLabel,
  ctaHref = '#',
  icon = 'local_shipping',
  variant = 'primary'
}) {
  const variantStyles = {
    primary: {
      background: 'var(--color-primary)',
      color: 'var(--color-primary-content)'
    },
    secondary: {
      background: 'var(--color-secondary)',
      color: '#ffffff'
    },
    neutral: {
      background: 'var(--color-neutral)',
      color: 'var(--color-neutral-content)'
    },
    warning: {
      background: 'var(--color-warning)',
      color: 'var(--color-warning-content)'
    }
  };
  const v = variantStyles[variant] || variantStyles.primary;
  const stripStyle = {
    ...v,
    padding: '0.625rem 1.5rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.625rem',
    width: '100%',
    boxSizing: 'border-box',
    borderBottom: '1.5px solid var(--color-base-content)'
  };
  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '17px',
    lineHeight: 1,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block'
  };
  const textStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 600,
    letterSpacing: '0.03em'
  };
  const ctaStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.75rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'inherit',
    textDecoration: 'underline',
    textUnderlineOffset: '2px',
    cursor: 'pointer',
    flexShrink: 0
  };
  return /*#__PURE__*/React.createElement("div", {
    style: stripStyle,
    role: "banner"
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, icon), /*#__PURE__*/React.createElement("span", {
    style: textStyle
  }, message), ctaLabel && /*#__PURE__*/React.createElement("a", {
    href: ctaHref,
    style: ctaStyle
  }, ctaLabel));
}
Object.assign(__ds_scope, { PromoStrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/PromoStrip.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
/**
 * Status badge. Uppercase Space Grotesk label in a colored chip.
 * Use for product status (NEW, SALE), category tags, and status indicators.
 */
function Badge({
  variant = 'primary',
  size = 'md',
  outline = false,
  children
}) {
  const colorMap = {
    primary: ['var(--color-primary)', 'var(--color-primary-content)'],
    secondary: ['var(--color-secondary)', '#ffffff'],
    accent: ['var(--color-accent)', 'var(--color-accent-content)'],
    neutral: ['var(--color-neutral)', 'var(--color-neutral-content)'],
    success: ['var(--color-success)', 'var(--color-success-content)'],
    warning: ['var(--color-warning)', 'var(--color-warning-content)'],
    error: ['var(--color-error)', 'var(--color-error-content)'],
    info: ['var(--color-info)', 'var(--color-info-content)'],
    ghost: ['var(--color-base-content)', 'var(--color-base-100)']
  };
  const sizeMap = {
    sm: ['0.15rem 0.45rem', '0.625rem'],
    md: ['0.2rem  0.6rem', '0.6875rem'],
    lg: ['0.3rem  0.8rem', '0.8125rem']
  };
  const [bg, fg] = colorMap[variant] || colorMap.primary;
  const [padding, fontSize] = sizeMap[size] || sizeMap.md;
  const style = {
    display: 'inline-flex',
    alignItems: 'center',
    padding,
    fontSize,
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    borderRadius: 'var(--radius-selector, 0.25rem)',
    lineHeight: 1,
    background: outline ? 'transparent' : bg,
    color: outline ? bg : fg,
    border: `1.5px solid ${bg}`
  };
  return /*#__PURE__*/React.createElement("span", {
    style: style
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ProductCard.jsx
try { (() => {
/**
 * E-commerce product card with square image, title, price, optional badge and CTA.
 * Features neo-brutalista border + hard offset shadow with hover lift animation.
 */
function ProductCard({
  title = 'Product Name',
  price = '$99.00',
  originalPrice,
  image,
  badge,
  href = '#',
  onAddToCart
}) {
  const [hovered, setHovered] = React.useState(false);
  const cardStyle = {
    background: 'var(--color-base-100)',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: 'var(--radius-box, 0.25rem)',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    transition: 'transform 150ms ease, box-shadow 150ms ease',
    transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
    boxShadow: hovered ? '5px 5px 0 0 var(--color-base-content)' : '2px 2px 0 0 var(--color-base-content)',
    textDecoration: 'none',
    color: 'inherit',
    cursor: 'pointer'
  };
  const imageWrapStyle = {
    position: 'relative',
    width: '100%',
    paddingBottom: '100%',
    background: 'var(--color-base-300)',
    overflow: 'hidden',
    borderBottom: '3px solid var(--color-primary)',
    flexShrink: 0
  };
  const imageStyle = {
    position: 'absolute',
    inset: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    display: 'block'
  };
  const badgeStyle = {
    position: 'absolute',
    top: '0.75rem',
    left: '0.75rem',
    zIndex: 1,
    background: 'var(--color-secondary)',
    color: '#fff',
    fontSize: '0.625rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    padding: '0.2rem 0.55rem',
    borderRadius: '0.25rem',
    lineHeight: 1,
    border: '1.5px solid transparent'
  };
  const bodyStyle = {
    padding: '1rem 1rem 1.25rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
    flex: 1
  };
  const titleStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '1rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '-0.01em',
    color: 'var(--color-base-content)',
    lineHeight: 1.25,
    margin: 0
  };
  const priceRowStyle = {
    display: 'flex',
    alignItems: 'baseline',
    gap: '0.5rem'
  };
  const priceStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '1rem',
    fontWeight: 700,
    color: 'var(--color-base-content)'
  };
  const originalPriceStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.875rem',
    color: 'var(--color-base-content)',
    opacity: 0.45,
    textDecoration: 'line-through'
  };
  const ctaBtnStyle = {
    marginTop: '0.625rem',
    padding: '0.5rem 1rem',
    background: 'transparent',
    color: 'var(--color-base-content)',
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.75rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    cursor: 'pointer',
    width: '100%',
    lineHeight: 1
  };
  const imgSrc = image || `https://picsum.photos/seed/${encodeURIComponent(title)}/400/400`;
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    style: cardStyle,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false)
  }, /*#__PURE__*/React.createElement("div", {
    style: imageWrapStyle
  }, /*#__PURE__*/React.createElement("img", {
    src: imgSrc,
    alt: title,
    style: imageStyle
  }), badge && /*#__PURE__*/React.createElement("span", {
    style: badgeStyle
  }, badge)), /*#__PURE__*/React.createElement("div", {
    style: bodyStyle
  }, /*#__PURE__*/React.createElement("h3", {
    style: titleStyle
  }, title), /*#__PURE__*/React.createElement("div", {
    style: priceRowStyle
  }, /*#__PURE__*/React.createElement("span", {
    style: priceStyle
  }, price), originalPrice && /*#__PURE__*/React.createElement("span", {
    style: originalPriceStyle
  }, originalPrice)), onAddToCart && /*#__PURE__*/React.createElement("button", {
    style: ctaBtnStyle,
    onClick: e => {
      e.preventDefault();
      onAddToCart();
    }
  }, "Add to Cart")));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
/**
 * Inline alert block. Semantic background color with icon and optional title.
 * Use inside forms, checkout flows, and content areas.
 */
function Alert({
  variant = 'info',
  title,
  children
}) {
  const configs = {
    info: {
      bg: 'var(--color-info)',
      fg: 'var(--color-info-content)',
      icon: 'info'
    },
    success: {
      bg: 'var(--color-success)',
      fg: 'var(--color-success-content)',
      icon: 'check_circle'
    },
    warning: {
      bg: 'var(--color-warning)',
      fg: 'var(--color-base-content)',
      icon: 'warning'
    },
    error: {
      bg: 'var(--color-error)',
      fg: 'var(--color-error-content)',
      icon: 'error'
    }
  };
  const c = configs[variant] || configs.info;
  const alertStyle = {
    display: 'flex',
    gap: '0.75rem',
    padding: '1rem 1.25rem',
    background: c.bg,
    color: c.fg,
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    width: '100%',
    boxSizing: 'border-box'
  };
  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '20px',
    lineHeight: 1.35,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: alertStyle,
    role: "alert"
  }, /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, c.icon), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.25rem',
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
      fontSize: '0.875rem',
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '0.04em'
    }
  }, title), children && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
      fontSize: '0.9375rem',
      lineHeight: 1.5,
      opacity: 0.85,
      margin: 0
    }
  }, children)));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
/**
 * Notification toast. Hard-shadow chip with semantic color and icon.
 * Self-dismisses after `duration` ms if provided.
 */
function Toast({
  variant = 'info',
  message = 'Something happened.',
  onDismiss,
  duration
}) {
  const [visible, setVisible] = React.useState(true);
  React.useEffect(() => {
    if (!duration) return;
    const t = setTimeout(() => {
      setVisible(false);
      if (onDismiss) onDismiss();
    }, duration);
    return () => clearTimeout(t);
  }, [duration]);
  if (!visible) return null;
  const configs = {
    info: {
      bg: 'var(--color-info)',
      fg: 'var(--color-info-content)',
      icon: 'info'
    },
    success: {
      bg: 'var(--color-success)',
      fg: 'var(--color-success-content)',
      icon: 'check_circle'
    },
    warning: {
      bg: 'var(--color-warning)',
      fg: 'var(--color-warning-content)',
      icon: 'warning'
    },
    error: {
      bg: 'var(--color-error)',
      fg: 'var(--color-error-content)',
      icon: 'error'
    }
  };
  const c = configs[variant] || configs.info;
  const toastStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0.875rem 1rem',
    background: c.bg,
    color: c.fg,
    border: '1.5px solid var(--color-base-content)',
    borderRadius: '0.25rem',
    boxShadow: '3px 3px 0 0 var(--color-base-content)',
    maxWidth: '24rem',
    width: '100%',
    boxSizing: 'border-box'
  };
  const iconStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '20px',
    lineHeight: 1,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block'
  };
  const closeBtnStyle = {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '18px',
    color: 'inherit',
    opacity: 0.65,
    padding: 0,
    lineHeight: 1,
    flexShrink: 0,
    fontStyle: 'normal',
    fontWeight: 'normal',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: toastStyle,
    role: "alert"
  }, /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, c.icon), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
      fontSize: '0.9375rem',
      lineHeight: 1.4,
      flex: 1
    }
  }, message), onDismiss && /*#__PURE__*/React.createElement("button", {
    style: closeBtnStyle,
    onClick: () => {
      setVisible(false);
      onDismiss();
    },
    "aria-label": "Dismiss"
  }, "close"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
/**
 * Custom checkbox with primary-color fill and Material Symbols checkmark.
 */
function Checkbox({
  label,
  checked = false,
  onChange,
  disabled = false,
  size = 'md',
  id,
  name
}) {
  const sizeMap = {
    sm: 16,
    md: 20,
    lg: 24
  };
  const sz = sizeMap[size] || 20;
  const handleClick = () => {
    if (!disabled && onChange) {
      onChange({
        target: {
          checked: !checked,
          name
        }
      });
    }
  };
  const wrapperStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '0.625rem',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    userSelect: 'none'
  };
  const boxStyle = {
    width: `${sz}px`,
    height: `${sz}px`,
    border: `1.5px solid ${checked ? 'var(--color-primary)' : 'var(--color-base-content)'}`,
    borderRadius: 'var(--radius-selector, 0.25rem)',
    background: checked ? 'var(--color-primary)' : 'var(--color-base-100)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'background 150ms ease, border-color 150ms ease, box-shadow 150ms ease',
    flexShrink: 0,
    boxShadow: checked ? '2px 2px 0 0 var(--color-primary)' : 'none'
  };
  const checkStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontSize: `${Math.round(sz * 0.72)}px`,
    color: 'var(--color-primary-content)',
    lineHeight: 1,
    fontWeight: 'normal',
    fontStyle: 'normal',
    opacity: checked ? 1 : 0,
    transition: 'opacity 100ms ease',
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block'
  };
  const labelStyle = {
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    fontSize: '0.9375rem',
    color: 'var(--color-base-content)',
    lineHeight: 1.4
  };
  return /*#__PURE__*/React.createElement("label", {
    style: wrapperStyle,
    onClick: handleClick
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    id: id,
    name: name,
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0,
      pointerEvents: 'none'
    },
    readOnly: true
  }), /*#__PURE__*/React.createElement("div", {
    style: boxStyle
  }, /*#__PURE__*/React.createElement("span", {
    style: checkStyle
  }, "check")), label && /*#__PURE__*/React.createElement("span", {
    style: labelStyle
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
/**
 * Text input field with label, hint, and error state.
 * Focus state shows primary-color border + hard shadow.
 */
function Input({
  label,
  type = 'text',
  placeholder = '',
  value,
  onChange,
  error,
  hint,
  size = 'md',
  required = false,
  disabled = false,
  name,
  id,
  autoComplete
}) {
  const [focused, setFocused] = React.useState(false);
  const sizes = {
    sm: {
      height: '36px',
      fontSize: '0.8125rem',
      padding: '0 0.75rem'
    },
    md: {
      height: '44px',
      fontSize: '0.9375rem',
      padding: '0 0.875rem'
    },
    lg: {
      height: '52px',
      fontSize: '1rem',
      padding: '0 1rem'
    }
  };
  const s = sizes[size] || sizes.md;
  const borderColor = error ? 'var(--color-error-content)' : focused ? 'var(--color-primary)' : 'var(--color-base-content)';
  const wrapperStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.375rem'
  };
  const labelStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)'
  };
  const inputStyle = {
    height: s.height,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    color: 'var(--color-base-content)',
    background: disabled ? 'var(--color-base-300)' : 'var(--color-base-100)',
    border: `1.5px solid ${borderColor}`,
    borderRadius: 'var(--radius-field, 0.25rem)',
    outline: 'none',
    width: '100%',
    transition: 'border-color 150ms ease, box-shadow 150ms ease',
    cursor: disabled ? 'not-allowed' : 'text',
    opacity: disabled ? 0.6 : 1,
    boxSizing: 'border-box',
    boxShadow: focused && !error ? '2px 2px 0 0 var(--color-primary)' : 'none'
  };
  const messageStyle = {
    fontSize: '0.8125rem',
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    color: error ? 'var(--color-error-content)' : 'var(--color-base-content)',
    opacity: error ? 1 : 0.6,
    margin: 0,
    lineHeight: 1.4
  };
  const fieldId = id || name;
  return /*#__PURE__*/React.createElement("div", {
    style: wrapperStyle
  }, label && /*#__PURE__*/React.createElement("label", {
    style: labelStyle,
    htmlFor: fieldId
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-secondary)',
      marginLeft: '3px'
    }
  }, "*")), /*#__PURE__*/React.createElement("input", {
    id: fieldId,
    name: name,
    type: type,
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    disabled: disabled,
    required: required,
    autoComplete: autoComplete,
    style: inputStyle,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false)
  }), (hint || error) && /*#__PURE__*/React.createElement("p", {
    style: messageStyle
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
/**
 * Dropdown select field with label and error state.
 * Custom expand_more icon replaces browser default chevron.
 */
function Select({
  label,
  options = [],
  value,
  onChange,
  placeholder = 'Select an option',
  error,
  size = 'md',
  disabled = false,
  name,
  id,
  required = false
}) {
  const [focused, setFocused] = React.useState(false);
  const sizes = {
    sm: {
      height: '36px',
      fontSize: '0.8125rem',
      padding: '0 2rem 0 0.75rem'
    },
    md: {
      height: '44px',
      fontSize: '0.9375rem',
      padding: '0 2rem 0 0.875rem'
    },
    lg: {
      height: '52px',
      fontSize: '1rem',
      padding: '0 2rem 0 1rem'
    }
  };
  const s = sizes[size] || sizes.md;
  const borderColor = error ? 'var(--color-error-content)' : focused ? 'var(--color-primary)' : 'var(--color-base-content)';
  const wrapperStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.375rem'
  };
  const labelStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)'
  };
  const selectStyle = {
    height: s.height,
    padding: s.padding,
    fontSize: s.fontSize,
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)',
    color: value ? 'var(--color-base-content)' : 'var(--color-base-content)',
    background: disabled ? 'var(--color-base-300)' : 'var(--color-base-100)',
    border: `1.5px solid ${borderColor}`,
    borderRadius: 'var(--radius-field, 0.25rem)',
    outline: 'none',
    width: '100%',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.6 : 1,
    appearance: 'none',
    WebkitAppearance: 'none',
    boxSizing: 'border-box',
    boxShadow: focused && !error ? '2px 2px 0 0 var(--color-primary)' : 'none',
    transition: 'border-color 150ms ease, box-shadow 150ms ease'
  };
  const iconStyle = {
    position: 'absolute',
    right: '0.625rem',
    top: '50%',
    transform: 'translateY(-50%)',
    pointerEvents: 'none',
    fontFamily: "'Material Symbols Outlined'",
    fontSize: '18px',
    color: 'var(--color-base-content)',
    lineHeight: 1,
    fontStyle: 'normal',
    fontWeight: 'normal'
  };
  const messageStyle = {
    fontSize: '0.8125rem',
    color: 'var(--color-error-content)',
    margin: 0,
    fontFamily: 'var(--font-body, "Atkinson Hyperlegible", sans-serif)'
  };
  const fieldId = id || name;
  const normalizedOptions = options.map(opt => typeof opt === 'string' ? {
    value: opt,
    label: opt
  } : opt);
  return /*#__PURE__*/React.createElement("div", {
    style: wrapperStyle
  }, label && /*#__PURE__*/React.createElement("label", {
    style: labelStyle,
    htmlFor: fieldId
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-secondary)',
      marginLeft: '3px'
    }
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", {
    id: fieldId,
    name: name,
    value: value,
    onChange: onChange,
    disabled: disabled,
    style: selectStyle,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false)
  }, placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), normalizedOptions.map((opt, i) => /*#__PURE__*/React.createElement("option", {
    key: i,
    value: opt.value
  }, opt.label))), /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, "expand_more")), error && /*#__PURE__*/React.createElement("p", {
    style: messageStyle
  }, error));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Navbar.jsx
try { (() => {
/**
 * Site navigation bar. Sticky top, thick bottom border, logo + nav links + action icons.
 */
function Navbar({
  logo = 'NEO-PLAY',
  navItems = [{
    label: 'Collections',
    href: '#'
  }, {
    label: 'New Arrivals',
    href: '#'
  }, {
    label: 'Brand',
    href: '#'
  }, {
    label: 'Blog',
    href: '#'
  }],
  onCartClick,
  cartCount = 0,
  onSearchClick,
  onAccountClick
}) {
  const navStyle = {
    position: 'sticky',
    top: 0,
    zIndex: 50,
    background: 'var(--color-base-200)',
    borderBottom: '3px solid var(--color-base-content)',
    display: 'flex',
    alignItems: 'center',
    padding: '0 1.5rem',
    height: 'var(--navbar-height, 64px)',
    gap: '2rem',
    boxSizing: 'border-box'
  };
  const logoStyle = {
    fontFamily: 'var(--font-display, "Fjalla One", sans-serif)',
    fontSize: '1.375rem',
    fontWeight: 700,
    color: 'var(--color-primary)',
    textDecoration: 'none',
    letterSpacing: '-0.02em',
    whiteSpace: 'nowrap',
    flexShrink: 0
  };
  const navListStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '1.75rem',
    flex: 1,
    listStyle: 'none',
    margin: 0,
    padding: 0
  };
  const navLinkStyle = {
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontSize: '0.8125rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: 'var(--color-base-content)',
    textDecoration: 'none',
    whiteSpace: 'nowrap'
  };
  const actionsStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.25rem',
    flexShrink: 0
  };
  const iconBtnBase = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '40px',
    height: '40px',
    background: 'transparent',
    border: 'none',
    borderRadius: '0.25rem',
    cursor: 'pointer',
    color: 'var(--color-base-content)',
    padding: 0
  };
  const iconSpanStyle = {
    fontFamily: "'Material Symbols Outlined'",
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: '22px',
    lineHeight: 1,
    letterSpacing: 'normal',
    textTransform: 'none',
    display: 'inline-block'
  };
  const cartBadgeStyle = {
    position: 'absolute',
    top: '7px',
    right: '7px',
    background: 'var(--color-secondary)',
    color: '#fff',
    fontSize: '0.5rem',
    fontFamily: 'var(--font-accent, "Space Grotesk", sans-serif)',
    fontWeight: 700,
    borderRadius: '100px',
    minWidth: '15px',
    height: '15px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    lineHeight: 1,
    padding: '0 2px'
  };
  return /*#__PURE__*/React.createElement("nav", {
    style: navStyle,
    "aria-label": "Main navigation"
  }, /*#__PURE__*/React.createElement("a", {
    href: "/",
    style: logoStyle
  }, logo), /*#__PURE__*/React.createElement("ul", {
    style: navListStyle
  }, navItems.map((item, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("a", {
    href: item.href,
    style: navLinkStyle,
    onClick: item.onClick ? e => {
      e.preventDefault();
      item.onClick();
    } : undefined
  }, item.label)))), /*#__PURE__*/React.createElement("div", {
    style: actionsStyle
  }, onSearchClick && /*#__PURE__*/React.createElement("button", {
    style: iconBtnBase,
    onClick: onSearchClick,
    "aria-label": "Search"
  }, /*#__PURE__*/React.createElement("span", {
    style: iconSpanStyle
  }, "search")), /*#__PURE__*/React.createElement("button", {
    style: {
      ...iconBtnBase,
      position: 'relative'
    },
    onClick: onCartClick,
    "aria-label": `Cart${cartCount > 0 ? `, ${cartCount} items` : ''}`
  }, /*#__PURE__*/React.createElement("span", {
    style: iconSpanStyle
  }, "shopping_bag"), cartCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: cartBadgeStyle
  }, cartCount)), /*#__PURE__*/React.createElement("button", {
    style: iconBtnBase,
    onClick: onAccountClick,
    "aria-label": "Account"
  }, /*#__PURE__*/React.createElement("span", {
    style: iconSpanStyle
  }, "person"))));
}
Object.assign(__ds_scope, { Navbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Navbar.jsx", error: String((e && e.message) || e) }); }

// guidelines/doc-page.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <doc-page> — paged-document shell for printable HTML.
 *
 * FIRST, decide how the document paginates — up front, before building:
 *
 * - FLOWING document (the default): write the whole document as one
 *   normal HTML flow inside <doc-page>; the browser's print engine
 *   splits it onto pages at export. Use for long-form documents with a
 *   single text flow: reports, memos, letters, essays.
 * - EXPLICIT pagination: a fixed set of pre-paginated pages, one
 *   <section class="page"> child per page. Use when the user asks for a
 *   specific page count, or the design implies one: a one-page resume, a
 *   two-sided flier, a poster, a certificate, a brochure — any richly
 *   laid-out document without a single text flow.
 * - If in doubt, ask the user as part of the build.
 *
 * PAGE SIZING — paper differs by country (letter vs A4), so the printed
 * sheet is not one fixed truth:
 * - FLOWING documents pin NO paper size: the print engine paginates
 *   onto the user's real paper, and the content reflows to it.
 * - EXPLICITLY PAGINATED documents print each page at a FIXED page box
 *   with overflow hidden — letter by default, size="a4" for a clearly
 *   metric user, the user's chosen paper when they export. Design each
 *   page to FILL that box, fitting letter and A4 alike without overlap.
 * - width/height pin an explicit fixed size, ONLY when the user gives
 *   one.
 * Never write your own @page rule or hard-code paper dimensions in the
 * content.
 *
 * Sizing modes (attributes):
 *   (none)                      — portrait: flowing docs use the user's
 *           paper; explicitly paginated pages use the named size box
 *           (letter unless size="a4")
 *   orientation="landscape"     — the same, landscape
 *   width / height              — explicit fixed size, ONLY when the user
 *           gives one (e.g. width="22in" height="30in" for a 22×30
 *           poster): the page IS the design's size, printed at true
 *           dimensions (or scaled onto the user's paper at print time).
 *           Any absolute CSS length: px/in/mm/cm/pt/pc.
 * The component announces the chosen mode to the host app at runtime (a
 * meta tag it injects), so the print path can inject the user's true
 * paper size.
 *
 * On screen the document renders on a desk background: a flowing
 * document as one tall scrolling sheet (Google Docs' pageless view);
 * explicitly paginated documents as one card per page.
 *
 * EXPLICIT pagination usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page>
 *     <section class="page" id="p1">…one page's design…</section>
 *     <section class="page" id="p2">…</section>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * How the page box works, concretely: each .page prints as ONE full-bleed
 * sheet at a FIXED physical size — letter by default (set size="a4" for
 * a clearly metric user), the user's chosen paper when they export —
 * with overflow hidden. Nothing scrolls and nothing reflows onto a next
 * sheet: content that misses the box is CLIPPED. Design each page to
 * FILL that page box, and to fit it — letter and A4 alike — without
 * overlap. Each page is a size container; don't size anything in
 * viewport units (they track the window, not the page), and never set
 * width or height on the .page section itself (the component sizes the
 * page box; an authored height like 100% is meaningless at print and is
 * overridden). The component owns the page box, the screen card chrome,
 * and the page breaks (never add your own break-before/after). Don't mix
 * .page sections with flowing content or header/footer slots in the same
 * document.
 *
 * FLOWING usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page margin="0.75in">
 *     <h1>Title</h1>
 *     <p>…body…</p>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * There is no manual page-splitting — the browser's print engine
 * paginates at export. Standard break-hygiene rules (`break-inside:
 * avoid` on figures, code blocks, images and table rows; `orphans/
 * widows: 3`) are applied so paragraphs and groups split cleanly. On
 * screen and at print, headings default to `text-wrap: balance` and
 * body text to `text-wrap: pretty`; the defaults have zero specificity,
 * so any text-wrap you declare wins.
 *
 * Other attributes:
 *   size    — letter | a4 | legal (default letter). Flowing documents:
 *           preview proportion only — it does NOT pin their printed
 *           paper (the print dialog's paper governs); leave it alone
 *           there. Explicitly paginated documents: it sets the page box
 *           the cards and the pinned @page share (the export dialog's
 *           choice overrides both at print) — set size="a4" for a
 *           clearly metric user. Scaled-fit: names the sheet the fit is
 *           computed against, same a4-for-metric-users advice.
 *   content-width / content-height — the design's own fixed dimensions
 *           (CSS lengths), for scaling a fixed-size design ONTO the
 *           named sheet: content lays out at exactly this size, and the
 *           component scales it to fit that sheet's printable area
 *           (centered horizontally, top-aligned; the export dialog
 *           re-fits to the user's actual paper choice where available).
 *           Both must be set; they do not change the page box. For pages
 *           WITHOUT running header/footer slots.
 *   margin  — printable inset on every page of a FLOWING document
 *           (default 0.75in); margin="0" makes pages full-bleed.
 *           Explicitly paginated pages are always full-bleed.
 *
 * Running header/footer (flowing documents only): give an element
 * `slot="header"` or `slot="footer"` and it repeats on every printed
 * page via `position: fixed`. To keep body text from sliding under it,
 * the component prints inside a single-cell table whose <thead>/<tfoot>
 * are spacers sized to the header/footer height — browsers repeat
 * thead/tfoot on every page, so each sheet's content starts below the
 * header and ends above the footer. On screen the header/footer render
 * once at the top/bottom of the sheet.
 *
 * At print the component injects `@page { margin: 0 }` (which leaves
 * Chrome no margin box to draw its date/URL/page-count header in) and
 * moves the visual margin onto the sheet's own padding. It also marks
 * the document as owning its print CSS (a
 * `meta[name="omelette-owns-print"]` it injects at runtime), so the
 * PDF export never injects page-geometry CSS of its own on top.
 *
 * Print best practices for the content you author:
 * - Multi-column text: use CSS columns (`column-count` +
 *   `column-gap`), never side-by-side flex/grid columns — only real
 *   CSS columns flow and break across pages. `column-span: all` lets
 *   a heading span the columns; `hyphens: auto` (needs `lang` on
 *   the html element) keeps narrow columns readable.
 * - Page breaks in flowing documents: `break-before: page` on an
 *   element that must start a new page (a chapter, an appendix). Add
 *   your own kept-together blocks (callouts, stat tiles, cards) to a
 *   `break-inside: avoid` rule, and keep each one shorter than a page.
 * - Extend `orphans: 3; widows: 3` to any custom text blocks you add
 *   (p and li are covered by default).
 * - Give long tables a <thead> — browsers repeat it on every printed
 *   page.
 * - No `position: fixed`/`sticky` and no viewport units in content:
 *   fixed elements stamp every printed page (running headers/footers go
 *   in the component's slots) and `100vh` mis-sizes at print.
 *
 * Author content as static HTML so the user can click-to-edit any text
 * directly. Do not set width/padding/background on the document body —
 * the component owns the sheet box.
 */
/* END USAGE */

(() => {
  const PAPER = {
    letter: ['8.5in', '11in'],
    a4: ['210mm', '297mm'],
    legal: ['8.5in', '14in']
  };
  const CSS_LENGTH = /^\d+(\.\d+)?(px|in|mm|cm|pt|pc)$/;
  // Unitless "0" is a valid CSS length and the natural way to write
  // margin="0"; normalise it to 0px so max()/calc() (which reject a bare
  // number) keep working.
  const safeLen = (v, fb) => {
    v = (v || '').trim();
    return v === '0' ? '0px' : CSS_LENGTH.test(v) ? v : fb;
  };
  // WebKit (Safari and every iOS browser shell) never repeats a table's
  // thead/tfoot on printed pages (WebKit bug 17205), so the spacer-borne
  // vertical margins of a FLOWING document reach only the first page
  // there. Engine check, not browser check: vendor is 'Apple Computer,
  // Inc.' exactly for WebKit and 'Google Inc.' for Blink.
  const WK_PRINT = /apple/i.test(navigator.vendor || '');
  // CSS length → px number (CSS absolute units are exact: 1in = 96px).
  // Returns NaN for anything safeLen would reject — callers gate on it.
  const PX_PER = {
    px: 1,
    in: 96,
    mm: 96 / 25.4,
    cm: 96 / 2.54,
    pt: 96 / 72,
    pc: 16
  };
  const toPx = v => {
    const m = /^(\d+(?:\.\d+)?)(px|in|mm|cm|pt|pc)$/.exec((v || '').trim());
    return m ? parseFloat(m[1]) * PX_PER[m[2]] : NaN;
  };
  const stylesheet = `
    :host {
      position: relative;
      display: block;
      /* When the viewport is narrower than the page, grow to wrap the
       * sheet (plus this padding) instead of staying viewport-width, so
       * the desk background and right margin reach the sheet's far edge
       * in the horizontal scroll. */
      min-width: max-content;
      min-height: 100vh;
      background: #f5f5f4;
      padding: 48px 24px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif;
      --doc-page-w: 8.5in;
      --doc-page-h: 11in;
      --doc-page-margin: 0.75in;
      --doc-hdr-h: 0px;
      --doc-ftr-h: 0px;
      --doc-hdr-pad: 0px;
      --doc-ftr-pad: 0px;
    }
    .sheet {
      width: var(--doc-page-w);
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 2px 10px rgba(20, 20, 19, 0.12);
      border-radius: 7px;
      box-sizing: border-box;
      padding: var(--doc-page-margin);
    }
    .frame { width: 100%; border-collapse: collapse; }
    /* Scaled-fit mode (content-width/content-height): the inner .fit box
     * lays the content out at its authored fixed size and scales it onto
     * the printable area; .fit-box reserves the scaled footprint in flow
     * (transforms don't affect layout) and centers it. Without the mode,
     * both divs are unstyled block pass-throughs. */
    /* Explicit pagination: direct .page children are the pages. The sheet
     * becomes a transparent stack and each page carries the card look on
     * screen; at print each page is exactly one full-bleed sheet. The
     * ::slotted defaults are deliberately weak (document CSS wins), so
     * authored page styling can override any of this. */
    .sheet.paginated {
      background: transparent;
      box-shadow: none;
      border-radius: 0;
      padding: 0;
    }
    .paginated ::slotted(.page) {
      position: relative;
      display: block;
      width: 100%;
      aspect-ratio: var(--doc-page-ar);
      container-type: size;
      overflow: hidden;
      box-sizing: border-box;
      background: #fff;
      border-radius: 7px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
      print-color-adjust: exact;
      -webkit-print-color-adjust: exact;
      break-inside: avoid;
    }
    .paginated ::slotted(.page:not(:first-child)) { margin-top: 1rem; }
    @media print {
      .sheet.paginated { padding: 0; }
      /* The flowing-document vertical inset lives on the repeating
       * thead/tfoot spacers, not the sheet padding — they must go too,
       * or each full-sheet .page is pushed ~margin down and spills onto
       * a second sheet. Paginated pages are full-bleed by definition
       * (content owns its insets). */
      .sheet.paginated .hdr-space,
      .sheet.paginated .ftr-space { height: 0; }
      .paginated ::slotted(.page) {
        border-radius: 0 !important;
        box-shadow: none !important;
        margin: 0 !important;
        /* Physical page-box sizing, no viewport units: Safari resolves
         * 100vh against the window, not the page box, so a vh-sized card
         * paginates wrong there. --doc-page-w/h are the named size by
         * default and are overridden to the user's chosen paper by the
         * export path, so every card is exactly one sheet either way.
         * Width + height (same source values as @page size) rather than
         * width + aspect-ratio: the ratio is a 6-decimal rounding of the
         * same division, and a few millionths of overflow would spill a
         * blank sheet after every page. The screen-only aspect-ratio
         * (preview proportions) must not leak into print. cqh typography
         * tracks the same box.
         *
         * Every declaration is !important: per CSS Scoping, unimportant
         * shadow ::slotted rules LOSE to the document context, so a page
         * section's authored inline style would silently beat this print
         * geometry. A model-authored height:100% did exactly that — the
         * percentage resolves as auto in the all-auto print ancestry, the
         * base rule's size containment turns auto into ZERO, and
         * overflow:hidden then paints nothing: a blank PDF with perfect
         * page boxes. At print the component's geometry is the design's
         * whole contract, so it must win over any authored sizing. */
        aspect-ratio: auto !important;
        width: var(--doc-page-w) !important;
        height: var(--doc-page-h) !important;
        overflow: hidden !important;
      }
      .paginated ::slotted(.page:not(:first-child)) {
        break-before: page !important;
        margin-top: 0 !important;
      }
    }
    .fit-mode .fit-box {
      width: calc(var(--doc-fit-w) * var(--doc-fit-scale));
      height: calc(var(--doc-fit-h) * var(--doc-fit-scale));
      margin: 0 auto;
      break-inside: avoid;
    }
    /* Monolithic at print: Blink slices a transform-scaled child at
     * fragmentainer boundaries mapped in UNSCALED layout coordinates
     * (transforms are paint-time), so the .fit box (authored size, e.g.
     * 1400x990) gets cut at the page's free block space and spills onto
     * a second sheet even though its SCALED footprint fits the page by
     * construction. overflow:hidden makes .fit-box a scroll container —
     * monolithic under fragmentation (css-break-3) — so the scaled
     * content prints atomically on one sheet. No clipping for content
     * within the authored box: .fit-box is calc-sized to exactly the
     * scaled footprint. (Content that bleeds past content-width/height
     * is clipped at the footprint — fit mode's contract; it previously
     * painted beyond it at print.) Print-only, so the screen rendering
     * keeps visible overflow for editor affordances.
     * The export path injects the same rule into frozen copies
     * (print-eval.ts om-print-fit-contain). The .fit-mode scope is
     * load-bearing: .fit-box wraps slotted content in EVERY mode, and an
     * unscoped overflow:hidden would make whole flowing documents
     * monolithic (one truncated sheet). overflow:hidden, never clip —
     * clip is not a scroll container, so not monolithic. */
    @media print {
      .fit-mode .fit-box { overflow: hidden; }
    }
    .fit-mode .fit {
      width: var(--doc-fit-w);
      height: var(--doc-fit-h);
      transform: scale(var(--doc-fit-scale));
      transform-origin: top left;
    }
    .frame td, .frame th { padding: 0; text-align: left; font-weight: inherit; }
    .hdr-space { height: var(--doc-hdr-h); }
    .ftr-space { height: var(--doc-ftr-h); }
    ::slotted([slot="header"]),
    ::slotted([slot="footer"]) { display: block; box-sizing: border-box; }
    @media print {
      :host { background: none; padding: 0; min-width: 0; min-height: 0; }
      .sheet {
        width: auto; margin: 0; box-shadow: none; border-radius: 0;
        padding: 0 var(--doc-page-margin);
      }
      /* The thead/tfoot spacers repeat on every page, so they carry the
       * vertical page margin (which the sheet's own padding cannot, since
       * that padding is consumed once on the first/last page). The running
       * header/footer are fixed inside that band. */
      /* The 0.35in is breathing room between a running header/footer and
       * the body; without one the spacer is exactly the page margin, so a
       * margin="0" full-bleed document gets truly full-bleed pages. */
      .hdr-space { height: max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))); }
      .ftr-space { height: max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))); }
      /* WebKit flowing documents: @page carries the vertical margin (see
       * _syncPrintPageRule), so the spacers keep only whatever a running
       * header/footer needs BEYOND it — page 1 would otherwise double its
       * top inset. Paginated sheets already zero their spacers above. */
      .sheet.wk-print:not(.paginated) .hdr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))) - var(--doc-page-margin))); }
      .sheet.wk-print:not(.paginated) .ftr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))) - var(--doc-page-margin))); }
      ::slotted([slot="header"]) {
        position: fixed; top: 0; left: 0; right: 0; margin: 0;
        padding: calc(var(--doc-page-margin) * 0.45) var(--doc-page-margin) 0;
      }
      ::slotted([slot="footer"]) {
        position: fixed; bottom: 0; left: 0; right: 0; margin: 0;
        padding: 0 var(--doc-page-margin) calc(var(--doc-page-margin) * 0.45);
      }
    }
  `;
  class DocPage extends HTMLElement {
    static get observedAttributes() {
      return ['size', 'width', 'height', 'margin', 'orientation', 'content-width', 'content-height'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._mo = typeof MutationObserver === 'function' ? new MutationObserver(() => this._scheduleMeasure()) : null;
    }

    /** The named paper's [w, h], swapped when orientation="landscape".
     *  Only the named size swaps — explicit width/height are exact values
     *  the author already oriented. */
    _paperSize() {
      const named = PAPER[(this.getAttribute('size') || '').toLowerCase()] || PAPER.letter;
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? [named[1], named[0]] : named;
    }
    get pageWidth() {
      return safeLen(this.getAttribute('width'), this._paperSize()[0]);
    }
    get pageHeight() {
      return safeLen(this.getAttribute('height'), this._paperSize()[1]);
    }
    get pageMargin() {
      return safeLen(this.getAttribute('margin'), '0.75in');
    }

    /** Scaled-fit mode's content box [w, h] as CSS lengths, or null when
     *  the mode is off (either attribute missing/invalid/zero — a partial
     *  declaration falls back to normal flow rather than guessing). */
    _contentFit() {
      const w = safeLen(this.getAttribute('content-width'), null);
      const h = safeLen(this.getAttribute('content-height'), null);
      if (!w || !h) return null;
      const wPx = toPx(w),
        hPx = toPx(h);
      return wPx > 0 && hPx > 0 ? [w, h, wPx, hPx] : null;
    }
    connectedCallback() {
      if (!this._sheet) this._render();
      this._syncSize();
      this._syncPrintPageRule();
      this._ensureTextWrapDefaults();
      this._ensureOwnsPrintMeta();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      if (this._mo) this._mo.observe(this, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true
      });
      this._onResize = () => this._scheduleMeasure();
      window.addEventListener('resize', this._onResize);
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(() => this._scheduleMeasure());
      }
      this._scheduleMeasure();
    }
    disconnectedCallback() {
      window.removeEventListener('resize', this._onResize);
      if (this._mo) this._mo.disconnect();
      if (this._raf) {
        cancelAnimationFrame(this._raf);
        this._raf = null;
      }
      // Drop the head rules when the last doc-page leaves, so a deleted
      // document's @page geometry and text-wrap defaults can't apply to
      // whatever replaces it.
      const survivor = document.querySelector('doc-page');
      if (!survivor) {
        ['doc-page-print', 'doc-page-text-wrap', 'doc-page-owns-print', 'doc-page-fixed-size', 'doc-page-print-sizing'].forEach(id => {
          const tag = document.getElementById(id);
          if (tag) tag.remove();
        });
        // A live deck-stage deferred its own print-sizing meta to ours —
        // hand the page-global meta over so the deck isn't left unmarked.
        const deck = document.querySelector('deck-stage');
        if (deck && typeof deck._ensurePrintSizingMeta === 'function') {
          deck._ensurePrintSizingMeta();
        }
      } else {
        // A departed owner hands each page-global meta to whatever
        // doc-page remains (or it's removed).
        if (typeof survivor._syncFixedSizeMeta === 'function') {
          survivor._syncFixedSizeMeta();
        }
        if (typeof survivor._syncPrintSizingMeta === 'function') {
          survivor._syncPrintSizingMeta();
        }
      }
    }
    attributeChangedCallback() {
      if (!this._sheet) return;
      this._syncSize();
      this._syncPrintPageRule();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      this._scheduleMeasure();
    }
    _render() {
      this._root.innerHTML = `
        <style>${stylesheet}</style>
        <style id="vars"></style>
        <div class="sheet" data-screen-label="Document">
          <table class="frame" role="presentation">
            <thead><tr><th><div class="hdr-space"><slot name="header"></slot></div></th></tr></thead>
            <tbody><tr><td class="body"><div class="fit-box"><div class="fit"><slot></slot></div></div></td></tr></tbody>
            <tfoot><tr><td><div class="ftr-space"><slot name="footer"></slot></div></td></tr></tfoot>
          </table>
        </div>`;
      this._sheet = this._root.querySelector('.sheet');
      this._vars = this._root.getElementById('vars');
    }

    /** Runtime sizing lives in a shadow <style> :host rule, never on the
     *  light-DOM host element, so serialize-persist can't write it back. */
    _syncSize(hdrH, ftrH) {
      // Scaled-fit mode: content at its authored size, scaled onto the
      // printable area (page minus margins on both axes). The factor is a
      // plain number var so calc(length * number) stays valid; 4 decimals
      // keeps the shadow style stable across re-measures. Upscaling is
      // allowed — print transforms are vector, so text and CSS stay crisp
      // (raster images soften, which the catalog bullet warns about).
      const fit = this._contentFit();
      let fitVars = '';
      if (fit) {
        const marginPx = toPx(this.pageMargin) || 0;
        const availW = toPx(this.pageWidth) - 2 * marginPx;
        const availH = toPx(this.pageHeight) - 2 * marginPx;
        const scale = Math.min(availW / fit[2], availH / fit[3]);
        if (scale > 0 && Number.isFinite(scale)) {
          fitVars = '--doc-fit-w:' + fit[0] + ';' + '--doc-fit-h:' + fit[1] + ';' + '--doc-fit-scale:' + scale.toFixed(4) + ';';
        }
      }
      this._sheet.classList.toggle('fit-mode', !!fitVars);
      // Numeric w/h ratio for the paginated page cards' aspect-ratio —
      // aspect-ratio takes a number, not a length ratio, so compute it
      // here (CSS length division isn't portable). 6 decimals keeps the
      // shadow style stable across re-syncs.
      const arW = toPx(this.pageWidth);
      const arH = toPx(this.pageHeight);
      const ar = arW > 0 && arH > 0 ? (arW / arH).toFixed(6) : '0.772727';
      this._vars.textContent = ':host{' + fitVars + '--doc-page-ar:' + ar + ';' + '--doc-page-w:' + this.pageWidth + ';' + '--doc-page-h:' + this.pageHeight + ';' + '--doc-page-margin:' + this.pageMargin + ';' + '--doc-hdr-h:' + (hdrH || 0) + 'px;' + '--doc-ftr-h:' + (ftrH || 0) + 'px;' + '--doc-hdr-pad:' + (hdrH ? '0.35in' : '0px') + ';' + '--doc-ftr-pad:' + (ftrH ? '0.35in' : '0px') + '}';
    }

    /** @page is a no-op inside shadow DOM, so the rule lives in <head>.
     *  Re-appended on every sync so it stays last in source order — the
     *  @page cascade is source-order per descriptor, so this rule wins
     *  over any other @page rule in the document.
     *
     *  The @page SIZE is pinned where the page box IS part of the design:
     *  explicit-fixed-size mode (width + height authored), scaled-fit
     *  mode (the named sheet the fit targets), and explicit pagination
     *  (the named size the cards share — so card and sheet agree on
     *  every print path, and the export path's chosen paper overrides
     *  BOTH with one later rule). For FLOWING documents no paper size is
     *  emitted at all — the true size comes from the user's preference,
     *  injected by the export path or chosen in the print dialog — so a
     *  flowing document never fights the paper it lands on.
     *  margin: 0 is emitted in every mode: it leaves Chrome no margin box
     *  to draw its date/URL/page-count header in, and the visual margin
     *  lives on the sheet's own padding. */
    _syncPrintPageRule() {
      const id = 'doc-page-print';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
      }
      document.head.appendChild(tag);
      // Three print-geometry regimes:
      // - true-size: the page IS the design — pin its exact size.
      // - scaled-fit (content-width/height): the fit factor is computed
      //   against the NAMED paper's printable area, so that paper must
      //   stay pinned or the scaled content overflows a smaller sheet
      //   (the export path re-fits and re-pins at print time on top).
      // - default modes: no paper size — but landscape still needs the
      //   paper-agnostic 'size: landscape' keyword, because the size
      //   descriptor is what carries orientation; without it a landscape
      //   document prints portrait whenever nothing injects a size.
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      // Explicit pagination pins the page box to the SAME values that
      // size the cards (the named size by default, the export path's
      // chosen paper when its later rule overrides both) — card and
      // sheet agree on every print path, and a mismatched real paper
      // shrinks-to-fit in the dialog instead of clipping a Letter card
      // on A4. Declared before the paginated read below so both derive
      // from one check.
      const paginatedNow = this.querySelector(':scope > .page') !== null;
      const sizeDescriptor = this._trueSizePx() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : this._contentFit() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : paginatedNow ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : landscape ? 'size: landscape; ' : '';
      // WebKit never repeats the thead/tfoot spacers that carry a flowing
      // document's vertical page margins (see WK_PRINT above), so pages
      // after the first print edge-to-edge there. Carry the VERTICAL
      // margins on @page for WebKit instead, and the shadow print CSS
      // trims the first-page spacers by the same amount (.sheet.wk-print
      // rules). Horizontal inset stays on the sheet's own padding in
      // every engine. Blink keeps margin: 0 (a nonzero margin there
      // re-opens the box Chrome draws its header furniture in). One cost,
      // learned in testing: Safari's own date/URL headers are a USER
      // dialog setting ("Print headers and footers") that renders in the
      // margin area when room exists — margin: 0 only suppressed it by
      // leaving no room, and no CSS controls it. The export dialog's
      // Safari guide teaches turning the setting off for flowing
      // documents. Explicitly paginated and fixed-size documents keep
      // margin: 0 everywhere: their pages ARE the sheet.
      const wkFlowing = WK_PRINT && !paginatedNow && !this._trueSizePx() && !this._contentFit();
      const marginDescriptor = wkFlowing ? 'margin: ' + this.pageMargin + ' 0; ' : 'margin: 0; ';
      // Shadow-internal marker (never serialized), kept in lockstep with
      // the @page decision above: the print CSS trims the first-page
      // spacers ONLY while @page actually carries the margins — a
      // true-size or scaled-fit sheet keeps margin: 0 and must keep its
      // spacers too. Re-synced here so attribute changes and pagination
      // flips move both together.
      if (this._sheet) this._sheet.classList.toggle('wk-print', wkFlowing);
      tag.textContent = '@page { ' + sizeDescriptor + marginDescriptor + '} ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; height: auto !important; overflow: visible !important; } ' + 'h1,h2,h3,h4,h5,h6 { break-after: avoid; } ' + 'figure,pre,blockquote,img,svg,tr { break-inside: avoid; } ' + 'p,li { orphans: 3; widows: 3; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; ' + 'backdrop-filter: none !important; -webkit-backdrop-filter: none !important; } ' + '*, *::before, *::after { animation-delay: -99s !important; animation-duration: .001s !important; ' + 'animation-iteration-count: 1 !important; animation-fill-mode: both !important; ' + 'animation-play-state: running !important; transition-duration: 0s !important; } }';
    }

    /** Typographic defaults for document text: balance headings, avoid
     *  widowed/orphaned words in body copy (browsers without text-wrap
     *  support drop the declarations). Zero-specificity via :where() so
     *  any text-wrap authored on those elements wins; document-level so the
     *  rules reach the slotted (light DOM) content — shadow styles can't.
     *  data-omelette-injected marks the tag for the host editor to strip
     *  at serialize, so it is never written back as authored source. */
    _ensureTextWrapDefaults() {
      if (document.getElementById('doc-page-text-wrap')) return;
      const tag = document.createElement('style');
      tag.id = 'doc-page-text-wrap';
      tag.setAttribute('data-omelette-injected', '');
      tag.textContent = ':where(h1,h2,h3,h4,h5,h6){text-wrap:balance}' + ':where(p,li,blockquote,figcaption){text-wrap:pretty}';
      document.head.appendChild(tag);
    }

    /** Declares that this document owns its print CSS. The instant-PDF
     *  export checks for the meta by NAME PRESENCE alone (content is
     *  ignored) and skips its automatic print-CSS injections, so the
     *  component's @page geometry is never overridden by a heuristic.
     *  data-omelette-injected keeps it out of serialized source. */
    _ensureOwnsPrintMeta() {
      if (document.getElementById('doc-page-owns-print')) return;
      const tag = document.createElement('meta');
      tag.id = 'doc-page-owns-print';
      tag.name = 'omelette-owns-print';
      tag.content = 'true';
      tag.setAttribute('data-omelette-injected', '');
      document.head.appendChild(tag);
    }

    /** This page's valid true-size page box (explicit width AND height)
     *  as [w, h] px ints, or null when the mode is off. */
    _trueSizePx() {
      if (!safeLen(this.getAttribute('width'), null) || !safeLen(this.getAttribute('height'), null)) return null;
      const w = Math.round(toPx(this.pageWidth));
      const h = Math.round(toPx(this.pageHeight));
      return w > 0 && h > 0 ? [w, h] : null;
    }

    /** True-size pages (explicit width AND height) also declare the page
     *  box as the preview size: the in-app preview reads
     *  meta[name="omelette-fixed-size"] (content "W,H" in px ints) and
     *  scales the sheet into view — without it an 18in poster previews at
     *  true size with scrollbars. Never overrides an author-set meta
     *  (only the component's own id is managed). The meta is page-global
     *  while doc-page instances are not, so every sync recomputes the
     *  page-wide owner — the first connected true-size doc-page — and a
     *  non-true-size sibling's sync can never delete the owner's meta.
     *  Removed when no true-size page remains (the owner's disconnect
     *  re-syncs via any survivor) or when an author-set meta exists. */
    _syncFixedSizeMeta() {
      const id = 'doc-page-fixed-size';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-fixed-size"]:not([data-omelette-injected])');
      // The page-wide owner, not this instance: an upgraded true-size page
      // anywhere in the document keeps the meta alive and sized.
      let box = null;
      for (const el of document.querySelectorAll('doc-page')) {
        box = typeof el._trueSizePx === 'function' ? el._trueSizePx() : null;
        if (box) break;
      }
      if (!box || authored) {
        if (own) own.remove();
        return;
      }
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-fixed-size';
      tag.content = box[0] + ',' + box[1];
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }

    /** This page's print-sizing mode: 'fixed' when an explicit width AND
     *  height are authored (the page is the design's own size), else the
     *  default paper in the authored orientation. */
    _printSizingMode() {
      if (this._trueSizePx()) return 'fixed';
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? 'default-landscape' : 'default-portrait';
    }

    /** Announces the print-sizing mode to the host app:
     *  meta[name="omelette-print-sizing"] with content 'default-portrait',
     *  'default-landscape', or 'fixed' (fixed pages also carry the
     *  omelette-fixed-size meta with the page box in px). The export path
     *  probes it to decide what true paper size to inject at print time —
     *  in the default modes the component emits no paper size of its own.
     *  Same page-global ownership rules as the fixed-size meta above:
     *  first connected doc-page owns it, an authored meta is never
     *  overridden, removed when no doc-page remains. */
    _syncPrintSizingMeta() {
      const id = 'doc-page-print-sizing';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-print-sizing"]:not([data-omelette-injected])');
      // A fixed page wins outright (mirroring the fixed-size loop above,
      // so the two metas can never contradict each other in a mixed
      // multi-page document); otherwise the first page's mode holds.
      let mode = null;
      for (const el of document.querySelectorAll('doc-page')) {
        if (typeof el._printSizingMode !== 'function') continue;
        const m = el._printSizingMode();
        if (m === 'fixed') {
          mode = m;
          break;
        }
        if (mode === null) mode = m;
      }
      if (!mode || authored) {
        if (own) own.remove();
        return;
      }
      // A deck-stage that connected first injected its own meta and
      // defers to any existing one — take it over, or the document ends
      // up with two conflicting injected metas (a doc-page page is the
      // document; the deck re-ensures its meta if every doc-page leaves).
      const deckMeta = document.getElementById('deck-stage-print-sizing');
      if (deckMeta) deckMeta.remove();
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-print-sizing';
      tag.content = mode;
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }
    _scheduleMeasure() {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        this._measure();
      });
    }

    /** Slot heights feed the print spacers (--doc-hdr-h / --doc-ftr-h), so
     *  they re-measure on content mutation, resize, and font load. The
     *  same pass detects explicit pagination (direct .page children) and
     *  toggles the sheet between the flowing-document card and the
     *  page-per-card stack — content edits can add or remove pages at any
     *  time, so this tracks the same mutations the measurement does. */
    _measure() {
      const hdr = this.querySelector(':scope > [slot="header"]');
      const ftr = this.querySelector(':scope > [slot="footer"]');
      const wasPaginated = this._sheet.classList.contains('paginated');
      this._sheet.classList.toggle('paginated', this.querySelector(':scope > .page') !== null);
      // The WebKit @page margin is flowing-only, so a pagination flip
      // must re-emit the rule (content edits can add or remove .page
      // sections at any time).
      if (this._sheet.classList.contains('paginated') !== wasPaginated) {
        this._syncPrintPageRule();
      }
      this._syncSize(hdr ? hdr.offsetHeight : 0, ftr ? ftr.offsetHeight : 0);
    }
  }
  if (!customElements.get('doc-page')) {
    customElements.define('doc-page', DocPage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "guidelines/doc-page.js", error: String((e && e.message) || e) }); }

// guidelines/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  // data-om-starter: inert presence marker — Claude Design's starter-usage
  // probe reads it. The closed panel renders nothing, so the marker rides
  // the <html> element as an attribute instead of a rendered node — zero
  // elements added, so page CSS (even structural selectors like
  // :nth-child) can never observe it. It records that the page WIRES a
  // tweaks panel, whether or not the panel is open. Keep this effect.
  React.useEffect(() => {
    document.documentElement.setAttribute('data-om-starter', 'tweaks-panel');
    return () => document.documentElement.removeAttribute('data-om-starter');
  }, []);
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "guidelines/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.CartDrawer = __ds_scope.CartDrawer;

__ds_ns.Newsletter = __ds_scope.Newsletter;

__ds_ns.PromoStrip = __ds_scope.PromoStrip;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Navbar = __ds_scope.Navbar;

})();
